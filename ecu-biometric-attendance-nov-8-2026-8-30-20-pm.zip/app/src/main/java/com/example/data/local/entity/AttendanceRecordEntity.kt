package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "attendance_records",
    indices = [
        Index(value = ["studentRegistrationNumber", "dateString", "sessionName"], unique = true),
        Index(value = ["dateString"]),
        Index(value = ["course", "academicLevel", "dateString"])
    ]
)
data class AttendanceRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: Long,
    val studentRegistrationNumber: String,
    val studentFullName: String,
    val dateString: String, // Format: YYYY-MM-DD
    val dayOfWeek: String, // Monday, Tuesday, Wednesday, Thursday, Friday
    val sessionName: String = "Morning Session",
    val course: String,
    val academicLevel: String,
    val academicYear: String,
    val status: String = "PRESENT", // PRESENT, ABSENT
    val verificationMethod: String = "BIOMETRIC_THUMBPRINT", // BIOMETRIC_FINGERPRINT, BIOMETRIC_THUMBPRINT, MANUAL_CORRECTION
    val verifiedTimestamp: Long = System.currentTimeMillis(),
    val verifiedTimeFormatted: String, // e.g. "08:30:15 AM"
    val markedByAdmin: String = "Biometric Scanner",
    val correctionReason: String? = null
)
