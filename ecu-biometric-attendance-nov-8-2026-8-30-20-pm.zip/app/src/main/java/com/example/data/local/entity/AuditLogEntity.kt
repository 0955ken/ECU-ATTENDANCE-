package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actionType: String, // MANUAL_CORRECTION, STUDENT_ADDED, STUDENT_DELETED, FINGERPRINT_ENROLLED, BACKUP_CREATED, RESTORE_PERFORMED
    val performedBy: String,
    val details: String,
    val targetRegistrationNumber: String? = null,
    val formattedTimestamp: String
)
