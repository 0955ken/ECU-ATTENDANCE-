package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AttendanceRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records ORDER BY verifiedTimestamp DESC")
    fun getAllAttendanceRecords(): Flow<List<AttendanceRecordEntity>>

    @Query("SELECT * FROM attendance_records WHERE dateString = :dateString ORDER BY verifiedTimestamp DESC")
    fun getAttendanceForDate(dateString: String): Flow<List<AttendanceRecordEntity>>

    @Query("SELECT * FROM attendance_records WHERE dateString BETWEEN :startDate AND :endDate ORDER BY dateString ASC, verifiedTimestamp ASC")
    fun getAttendanceForDateRange(startDate: String, endDate: String): Flow<List<AttendanceRecordEntity>>

    @Query("SELECT * FROM attendance_records WHERE studentRegistrationNumber = :regNo ORDER BY verifiedTimestamp DESC")
    fun getAttendanceForStudent(regNo: String): Flow<List<AttendanceRecordEntity>>

    @Query("""
        SELECT * FROM attendance_records 
        WHERE course = :course 
          AND academicLevel = :level 
          AND dateString IN (:dates)
        ORDER BY dateString ASC
    """)
    fun getAttendanceForCourseLevelDates(course: String, level: String, dates: List<String>): Flow<List<AttendanceRecordEntity>>

    @Query("""
        SELECT * FROM attendance_records 
        WHERE studentRegistrationNumber = :regNo 
          AND dateString = :dateString 
          AND sessionName = :sessionName 
        LIMIT 1
    """)
    suspend fun checkExistingAttendance(
        regNo: String,
        dateString: String,
        sessionName: String
    ): AttendanceRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceRecord(record: AttendanceRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendanceRecords(records: List<AttendanceRecordEntity>): List<Long>

    @Update
    suspend fun updateAttendanceRecord(record: AttendanceRecordEntity)

    @Delete
    suspend fun deleteAttendanceRecord(record: AttendanceRecordEntity)

    @Query("DELETE FROM attendance_records WHERE id = :id")
    suspend fun deleteAttendanceById(id: Long)

    @Query("SELECT COUNT(*) FROM attendance_records")
    fun getTotalAttendanceCount(): Flow<Int>

    @Query("SELECT COUNT(DISTINCT studentRegistrationNumber) FROM attendance_records WHERE dateString = :dateString AND status = 'PRESENT'")
    fun getPresentCountForDate(dateString: String): Flow<Int>

    @Query("SELECT COUNT(DISTINCT studentRegistrationNumber) FROM attendance_records WHERE dateString = :dateString AND status = 'ABSENT'")
    fun getAbsentCountForDate(dateString: String): Flow<Int>

    @Query("DELETE FROM attendance_records")
    suspend fun clearAllAttendance()
}
