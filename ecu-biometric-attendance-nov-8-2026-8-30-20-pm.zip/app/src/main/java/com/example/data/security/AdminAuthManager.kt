package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.security.MessageDigest

class AdminAuthManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ecu_admin_security_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _adminUsername = MutableStateFlow(getStoredUsername())
    val adminUsername: StateFlow<String> = _adminUsername.asStateFlow()

    private val _sessionTimeoutMinutes = MutableStateFlow(getStoredTimeoutMinutes())
    val sessionTimeoutMinutes: StateFlow<Int> = _sessionTimeoutMinutes.asStateFlow()

    private val _sessionSecondsRemaining = MutableStateFlow(getStoredTimeoutMinutes() * 60L)
    val sessionSecondsRemaining: StateFlow<Long> = _sessionSecondsRemaining.asStateFlow()

    private var lastActivityTime: Long = System.currentTimeMillis()
    private var timerJob: Job? = null

    init {
        // Initialize default admin if not created
        if (!prefs.contains(KEY_ADMIN_PASS_HASH)) {
            val defaultSalt = "ECU_SALT_2026"
            val defaultHash = hashPassword("ecu2026", defaultSalt)
            prefs.edit()
                .putString(KEY_ADMIN_USERNAME, "admin")
                .putString(KEY_ADMIN_PASS_HASH, defaultHash)
                .putString(KEY_ADMIN_SALT, defaultSalt)
                .putInt(KEY_TIMEOUT_MINUTES, 15)
                .apply()
        }
    }

    private fun getStoredUsername(): String {
        return prefs.getString(KEY_ADMIN_USERNAME, "admin") ?: "admin"
    }

    private fun getStoredTimeoutMinutes(): Int {
        return prefs.getInt(KEY_TIMEOUT_MINUTES, 15)
    }

    fun login(usernameInput: String, passwordInput: String): Boolean {
        val storedUsername = getStoredUsername()
        val storedHash = prefs.getString(KEY_ADMIN_PASS_HASH, "") ?: ""
        val storedSalt = prefs.getString(KEY_ADMIN_SALT, "ECU_SALT_2026") ?: "ECU_SALT_2026"

        val inputHash = hashPassword(passwordInput.trim(), storedSalt)
        if (usernameInput.trim().equals(storedUsername, ignoreCase = true) && inputHash == storedHash) {
            _isLoggedIn.value = true
            _adminUsername.value = storedUsername
            resetActivityTimer()
            startSessionMonitor()
            return true
        }
        return false
    }

    fun logout() {
        _isLoggedIn.value = false
        timerJob?.cancel()
        timerJob = null
    }

    fun recordUserActivity() {
        if (_isLoggedIn.value) {
            lastActivityTime = System.currentTimeMillis()
            _sessionSecondsRemaining.value = _sessionTimeoutMinutes.value * 60L
        }
    }

    fun changePassword(oldPassword: String, newPassword: String): Result<Unit> {
        val storedHash = prefs.getString(KEY_ADMIN_PASS_HASH, "") ?: ""
        val storedSalt = prefs.getString(KEY_ADMIN_SALT, "ECU_SALT_2026") ?: "ECU_SALT_2026"
        val oldHash = hashPassword(oldPassword.trim(), storedSalt)

        if (oldHash != storedHash) {
            return Result.failure(Exception("Current password is incorrect"))
        }
        if (newPassword.trim().length < 4) {
            return Result.failure(Exception("New password must be at least 4 characters"))
        }

        val newSalt = System.currentTimeMillis().toString()
        val newHash = hashPassword(newPassword.trim(), newSalt)
        prefs.edit()
            .putString(KEY_ADMIN_PASS_HASH, newHash)
            .putString(KEY_ADMIN_SALT, newSalt)
            .apply()

        recordUserActivity()
        return Result.success(Unit)
    }

    fun updateAdminProfile(newUsername: String, timeoutMinutes: Int) {
        prefs.edit()
            .putString(KEY_ADMIN_USERNAME, newUsername.trim())
            .putInt(KEY_TIMEOUT_MINUTES, timeoutMinutes)
            .apply()
        _adminUsername.value = newUsername.trim()
        _sessionTimeoutMinutes.value = timeoutMinutes
        _sessionSecondsRemaining.value = timeoutMinutes * 60L
    }

    private fun resetActivityTimer() {
        lastActivityTime = System.currentTimeMillis()
        _sessionSecondsRemaining.value = _sessionTimeoutMinutes.value * 60L
    }

    private fun startSessionMonitor() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _isLoggedIn.value) {
                delay(1000)
                val elapsedSeconds = (System.currentTimeMillis() - lastActivityTime) / 1000
                val totalAllowedSeconds = _sessionTimeoutMinutes.value * 60L
                val remaining = totalAllowedSeconds - elapsedSeconds
                if (remaining <= 0) {
                    _sessionSecondsRemaining.value = 0
                    logout()
                } else {
                    _sessionSecondsRemaining.value = remaining
                }
            }
        }
    }

    private fun hashPassword(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest((password + salt).toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_ADMIN_USERNAME = "key_admin_username"
        private const val KEY_ADMIN_PASS_HASH = "key_admin_pass_hash"
        private const val KEY_ADMIN_SALT = "key_admin_salt"
        private const val KEY_TIMEOUT_MINUTES = "key_timeout_minutes"
    }
}
