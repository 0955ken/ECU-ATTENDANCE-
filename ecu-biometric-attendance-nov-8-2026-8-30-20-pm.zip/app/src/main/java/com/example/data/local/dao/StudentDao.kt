package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.StudentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY fullName ASC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE course = :course AND academicLevel = :level ORDER BY fullName ASC")
    fun getStudentsByCourseAndLevel(course: String, level: String): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentById(id: Long): StudentEntity?

    @Query("SELECT * FROM students WHERE registrationNumber = :regNo LIMIT 1")
    suspend fun getStudentByRegNumber(regNo: String): StudentEntity?

    @Query("""
        SELECT * FROM students 
        WHERE fullName LIKE '%' || :query || '%' 
           OR registrationNumber LIKE '%' || :query || '%'
           OR studentIdNumber LIKE '%' || :query || '%'
           OR faculty LIKE '%' || :query || '%'
           OR department LIKE '%' || :query || '%'
           OR course LIKE '%' || :query || '%'
        ORDER BY fullName ASC
    """)
    fun searchStudents(query: String): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertStudent(student: StudentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>): List<Long>

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Delete
    suspend fun deleteStudent(student: StudentEntity)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudentById(id: Long)

    @Query("SELECT COUNT(*) FROM students")
    fun getStudentCount(): Flow<Int>

    @Query("SELECT * FROM students WHERE isBiometricRegistered = 1")
    suspend fun getBiometricRegisteredStudents(): List<StudentEntity>

    @Query("SELECT DISTINCT faculty FROM students ORDER BY faculty ASC")
    fun getDistinctFaculties(): Flow<List<String>>

    @Query("SELECT DISTINCT course FROM students ORDER BY course ASC")
    fun getDistinctCourses(): Flow<List<String>>

    @Query("SELECT DISTINCT academicLevel FROM students ORDER BY academicLevel ASC")
    fun getDistinctLevels(): Flow<List<String>>

    @Query("DELETE FROM students")
    suspend fun clearAllStudents()
}
