package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "academic_programs")
data class AcademicProgramEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val faculty: String,
    val department: String,
    val programmeName: String,
    val programmeCode: String,
    val levels: String = "Year 1,Year 2,Year 3,Year 4",
    val academicYear: String = "2025/2026",
    val description: String = ""
)
