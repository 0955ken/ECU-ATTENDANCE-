package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "students",
    indices = [
        Index(value = ["registrationNumber"], unique = true),
        Index(value = ["studentIdNumber"]),
        Index(value = ["course", "academicLevel"])
    ]
)
data class StudentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val registrationNumber: String,
    val studentIdNumber: String,
    val faculty: String,
    val department: String,
    val course: String,
    val academicYear: String,
    val academicLevel: String,
    val biometricTemplate: String? = null,
    val biometricFingerType: String = "Right Thumb",
    val isBiometricRegistered: Boolean = false,
    val photoPath: String? = null,
    val phoneNumber: String = "",
    val email: String = "",
    val gender: String = "Not Specified",
    val createdAt: Long = System.currentTimeMillis()
)
