package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.biometrics.BiometricHardwareManager
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AcademicProgramEntity
import com.example.data.local.entity.AttendanceRecordEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.StudentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ImportSummary(
    val totalProcessed: Int,
    val successfulCount: Int,
    val duplicateCount: Int,
    val failedCount: Int,
    val errorMessages: List<String>
)

class AttendanceRepository(
    private val context: Context,
    private val database: AppDatabase,
    val biometricHardwareManager: BiometricHardwareManager
) {
    private val studentDao = database.studentDao()
    private val attendanceDao = database.attendanceDao()
    private val programDao = database.academicProgramDao()
    private val auditLogDao = database.auditLogDao()

    val allStudents: Flow<List<StudentEntity>> = studentDao.getAllStudents()
    val studentCount: Flow<Int> = studentDao.getStudentCount()
    val totalAttendanceCount: Flow<Int> = attendanceDao.getTotalAttendanceCount()
    val allPrograms: Flow<List<AcademicProgramEntity>> = programDao.getAllPrograms()
    val recentAuditLogs: Flow<List<AuditLogEntity>> = auditLogDao.getRecentAuditLogs()

    fun searchStudents(query: String): Flow<List<StudentEntity>> = studentDao.searchStudents(query)
    fun getDistinctFaculties(): Flow<List<String>> = studentDao.getDistinctFaculties()
    fun getDistinctCourses(): Flow<List<String>> = studentDao.getDistinctCourses()
    fun getDistinctLevels(): Flow<List<String>> = studentDao.getDistinctLevels()

    fun getAttendanceForDate(dateString: String): Flow<List<AttendanceRecordEntity>> =
        attendanceDao.getAttendanceForDate(dateString)

    fun getAttendanceForDateRange(start: String, end: String): Flow<List<AttendanceRecordEntity>> =
        attendanceDao.getAttendanceForDateRange(start, end)

    fun getAttendanceForStudent(regNo: String): Flow<List<AttendanceRecordEntity>> =
        attendanceDao.getAttendanceForStudent(regNo)

    fun getAttendanceForCourseLevelDates(course: String, level: String, dates: List<String>): Flow<List<AttendanceRecordEntity>> =
        attendanceDao.getAttendanceForCourseLevelDates(course, level, dates)

    fun getStudentsByCourseAndLevel(course: String, level: String): Flow<List<StudentEntity>> =
        studentDao.getStudentsByCourseAndLevel(course, level)

    suspend fun getStudentById(id: Long): StudentEntity? = studentDao.getStudentById(id)
    suspend fun getStudentByRegNumber(regNo: String): StudentEntity? = studentDao.getStudentByRegNumber(regNo)
    suspend fun getBiometricRegisteredStudents(): List<StudentEntity> = studentDao.getBiometricRegisteredStudents()

    suspend fun addStudent(student: StudentEntity, adminUser: String): Result<Long> = withContext(Dispatchers.IO) {
        val existing = studentDao.getStudentByRegNumber(student.registrationNumber.trim())
        if (existing != null) {
            return@withContext Result.failure(Exception("Registration number '${student.registrationNumber}' already exists"))
        }

        try {
            val id = studentDao.insertStudent(student.copy(registrationNumber = student.registrationNumber.trim()))
            addAuditLog(
                actionType = "STUDENT_ADDED",
                admin = adminUser,
                details = "Registered student: ${student.fullName} (${student.registrationNumber})",
                regNo = student.registrationNumber
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateStudent(student: StudentEntity, adminUser: String) = withContext(Dispatchers.IO) {
        studentDao.updateStudent(student)
        addAuditLog(
            actionType = "STUDENT_UPDATED",
            admin = adminUser,
            details = "Updated student information for ${student.fullName} (${student.registrationNumber})",
            regNo = student.registrationNumber
        )
    }

    suspend fun deleteStudent(student: StudentEntity, adminUser: String) = withContext(Dispatchers.IO) {
        studentDao.deleteStudent(student)
        addAuditLog(
            actionType = "STUDENT_DELETED",
            admin = adminUser,
            details = "Removed student: ${student.fullName} (${student.registrationNumber})",
            regNo = student.registrationNumber
        )
    }

    suspend fun saveStudentPhoto(studentId: Long, sourceUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val photoDir = File(context.filesDir, "student_photos").apply { if (!exists()) mkdirs() }
            val destFile = File(photoDir, "student_${studentId}_${System.currentTimeMillis()}.jpg")

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            val photoPath = destFile.absolutePath
            val student = studentDao.getStudentById(studentId)
            if (student != null) {
                studentDao.updateStudent(student.copy(photoPath = photoPath))
            }
            photoPath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun registerBiometricTemplate(
        studentId: Long,
        fingerType: String,
        templateString: String,
        adminUser: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val student = studentDao.getStudentById(studentId) ?: return@withContext Result.failure(Exception("Student not found"))
        val updated = student.copy(
            biometricTemplate = templateString,
            biometricFingerType = fingerType,
            isBiometricRegistered = true
        )
        studentDao.updateStudent(updated)
        addAuditLog(
            actionType = "BIOMETRIC_ENROLLED",
            admin = adminUser,
            details = "Enrolled $fingerType template for ${student.fullName} (${student.registrationNumber})",
            regNo = student.registrationNumber
        )
        Result.success(Unit)
    }

    /**
     * Biometric verification attendance marking.
     * Prevents duplicate entries on the same day and session.
     */
    suspend fun markBiometricAttendance(
        student: StudentEntity,
        sessionName: String = "Morning Session",
        method: String = "BIOMETRIC_THUMBPRINT"
    ): Result<AttendanceRecordEntity> = withContext(Dispatchers.IO) {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
        val dayOfWeekFormat = SimpleDateFormat("EEEE", Locale.getDefault())

        val dateStr = dateFormat.format(calendar.time)
        val timeStr = timeFormat.format(calendar.time)
        val dayOfWeek = dayOfWeekFormat.format(calendar.time)

        // Duplicate prevention check
        val existing = attendanceDao.checkExistingAttendance(
            regNo = student.registrationNumber,
            dateString = dateStr,
            sessionName = sessionName
        )

        if (existing != null) {
            return@withContext Result.failure(
                Exception("DUPLICATE: ${student.fullName} was already marked ${existing.status} today at ${existing.verifiedTimeFormatted}")
            )
        }

        val record = AttendanceRecordEntity(
            studentId = student.id,
            studentRegistrationNumber = student.registrationNumber,
            studentFullName = student.fullName,
            dateString = dateStr,
            dayOfWeek = dayOfWeek,
            sessionName = sessionName,
            course = student.course,
            academicLevel = student.academicLevel,
            academicYear = student.academicYear,
            status = "PRESENT",
            verificationMethod = method,
            verifiedTimestamp = System.currentTimeMillis(),
            verifiedTimeFormatted = timeStr,
            markedByAdmin = "ECU Biometric Scanner"
        )

        val id = attendanceDao.insertAttendanceRecord(record)
        Result.success(record.copy(id = id))
    }

    /**
     * Manual attendance correction with mandatory administrator, date, and reason recording.
     */
    suspend fun recordManualAttendanceCorrection(
        student: StudentEntity,
        dateString: String,
        dayOfWeek: String,
        sessionName: String,
        newStatus: String,
        adminUser: String,
        reason: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (reason.trim().isEmpty()) {
            return@withContext Result.failure(Exception("A valid correction reason is required by university policy"))
        }

        val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
        val timeStr = timeFormat.format(Date())

        val existing = attendanceDao.checkExistingAttendance(
            regNo = student.registrationNumber,
            dateString = dateString,
            sessionName = sessionName
        )

        val record = AttendanceRecordEntity(
            id = existing?.id ?: 0,
            studentId = student.id,
            studentRegistrationNumber = student.registrationNumber,
            studentFullName = student.fullName,
            dateString = dateString,
            dayOfWeek = dayOfWeek,
            sessionName = sessionName,
            course = student.course,
            academicLevel = student.academicLevel,
            academicYear = student.academicYear,
            status = newStatus,
            verificationMethod = "MANUAL_CORRECTION",
            verifiedTimestamp = System.currentTimeMillis(),
            verifiedTimeFormatted = timeStr,
            markedByAdmin = adminUser,
            correctionReason = reason.trim()
        )

        attendanceDao.insertAttendanceRecord(record)

        addAuditLog(
            actionType = "MANUAL_CORRECTION",
            admin = adminUser,
            details = "Manual attendance set to $newStatus for ${student.fullName} ($dateString) - Reason: $reason",
            regNo = student.registrationNumber
        )

        Result.success(Unit)
    }

    suspend fun addProgram(program: AcademicProgramEntity) = withContext(Dispatchers.IO) {
        programDao.insertProgram(program)
    }

    suspend fun updateProgram(program: AcademicProgramEntity) = withContext(Dispatchers.IO) {
        programDao.updateProgram(program)
    }

    suspend fun deleteProgram(id: Long) = withContext(Dispatchers.IO) {
        programDao.deleteProgramById(id)
    }

    suspend fun addAuditLog(
        actionType: String,
        admin: String,
        details: String,
        regNo: String? = null
    ) = withContext(Dispatchers.IO) {
        val timeFormat = SimpleDateFormat("yyyy-MM-dd hh:mm:ss a", Locale.getDefault())
        val log = AuditLogEntity(
            actionType = actionType,
            performedBy = admin,
            details = details,
            targetRegistrationNumber = regNo,
            formattedTimestamp = timeFormat.format(Date())
        )
        auditLogDao.insertAuditLog(log)
    }

    /**
     * CSV / Excel Parser for student batch upload.
     * Expects columns: Full Name, Registration Number, Faculty, Department, Course, Academic Year, Class Level, Student ID
     */
    suspend fun parseAndImportCsv(csvText: String, adminUser: String): ImportSummary = withContext(Dispatchers.IO) {
        val lines = csvText.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            return@withContext ImportSummary(0, 0, 0, 0, listOf("The uploaded file is empty"))
        }

        var successCount = 0
        var duplicateCount = 0
        var failedCount = 0
        val errors = mutableListOf<String>()

        val startIndex = if (lines[0].contains("Registration", ignoreCase = true) || lines[0].contains("Name", ignoreCase = true)) 1 else 0

        for (i in startIndex until lines.size) {
            val line = lines[i]
            val parts = line.split(",").map { it.trim().removeSurrounding("\"") }
            if (parts.size < 3) {
                failedCount++
                errors.add("Line ${i + 1}: Insufficient columns. Minimum required: Name, Reg No, Course.")
                continue
            }

            val fullName = parts.getOrNull(0) ?: ""
            val regNo = parts.getOrNull(1) ?: ""
            val faculty = parts.getOrNull(2) ?: "Faculty of Business Administration"
            val department = parts.getOrNull(3) ?: "Management"
            val course = parts.getOrNull(4) ?: "Bachelor of Business Administration"
            val academicYear = parts.getOrNull(5) ?: "2025/2026"
            val classLevel = parts.getOrNull(6) ?: "Year 2"
            val studentId = parts.getOrNull(7) ?: "ECU-${regNo.replace("/", "-")}"

            if (fullName.isBlank() || regNo.isBlank()) {
                failedCount++
                errors.add("Line ${i + 1}: Name or Registration Number cannot be empty.")
                continue
            }

            val existing = studentDao.getStudentByRegNumber(regNo)
            if (existing != null) {
                duplicateCount++
                errors.add("Line ${i + 1}: Duplicate registration number '$regNo' skipped.")
                continue
            }

            val student = StudentEntity(
                fullName = fullName,
                registrationNumber = regNo,
                studentIdNumber = studentId,
                faculty = faculty,
                department = department,
                course = course,
                academicYear = academicYear,
                academicLevel = classLevel,
                isBiometricRegistered = false
            )

            try {
                studentDao.insertStudent(student)
                successCount++
            } catch (e: Exception) {
                failedCount++
                errors.add("Line ${i + 1}: Failed to save - ${e.message}")
            }
        }

        addAuditLog(
            actionType = "BATCH_IMPORT",
            admin = adminUser,
            details = "Imported student list: $successCount succeeded, $duplicateCount duplicates, $failedCount failed"
        )

        ImportSummary(
            totalProcessed = lines.size - startIndex,
            successfulCount = successCount,
            duplicateCount = duplicateCount,
            failedCount = failedCount,
            errorMessages = errors
        )
    }

    suspend fun exportStudentsCsv(): String = withContext(Dispatchers.IO) {
        val builder = StringBuilder()
        builder.append("No,Full Name,Registration Number,Student ID,Faculty,Department,Course,Academic Year,Class Level,Biometric Status\n")
        val students = studentDao.getBiometricRegisteredStudents() // or all students
        // To get all:
        val all = database.openHelper.readableDatabase.query("SELECT * FROM students ORDER BY fullName ASC")
        var idx = 1
        all.use { cursor ->
            val nameCol = cursor.getColumnIndex("fullName")
            val regCol = cursor.getColumnIndex("registrationNumber")
            val idCol = cursor.getColumnIndex("studentIdNumber")
            val facCol = cursor.getColumnIndex("faculty")
            val deptCol = cursor.getColumnIndex("department")
            val courseCol = cursor.getColumnIndex("course")
            val yearCol = cursor.getColumnIndex("academicYear")
            val levelCol = cursor.getColumnIndex("academicLevel")
            val bioCol = cursor.getColumnIndex("isBiometricRegistered")

            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol)
                val reg = cursor.getString(regCol)
                val sId = cursor.getString(idCol)
                val fac = cursor.getString(facCol)
                val dept = cursor.getString(deptCol)
                val course = cursor.getString(courseCol)
                val yr = cursor.getString(yearCol)
                val lvl = cursor.getString(levelCol)
                val bio = if (cursor.getInt(bioCol) == 1) "Registered" else "Pending"

                builder.append("$idx,\"$name\",\"$reg\",\"$sId\",\"$fac\",\"$dept\",\"$course\",\"$yr\",\"$lvl\",\"$bio\"\n")
                idx++
            }
        }
        builder.toString()
    }

    suspend fun exportAttendanceCsv(records: List<AttendanceRecordEntity>): String = withContext(Dispatchers.IO) {
        val builder = StringBuilder()
        builder.append("No,Student Name,Registration Number,Date,Day,Session,Course,Level,Status,Verification Method,Time,Admin/Scanner,Correction Reason\n")
        records.forEachIndexed { idx, r ->
            builder.append("${idx + 1},\"${r.studentFullName}\",\"${r.studentRegistrationNumber}\",\"${r.dateString}\",\"${r.dayOfWeek}\",\"${r.sessionName}\",\"${r.course}\",\"${r.academicLevel}\",\"${r.status}\",\"${r.verificationMethod}\",\"${r.verifiedTimeFormatted}\",\"${r.markedByAdmin}\",\"${r.correctionReason ?: ""}\"\n")
        }
        builder.toString()
    }

    suspend fun createDatabaseBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("university", "Emmanuel Christian University (ECU)")
        root.put("system", "ECU DATA ATTENDANCE")
        root.put("version", "1.0")
        root.put("backupTimestamp", System.currentTimeMillis())

        val studentsArray = JSONArray()
        val all = database.openHelper.readableDatabase.query("SELECT * FROM students")
        all.use { cursor ->
            while (cursor.moveToNext()) {
                val sObj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    val colName = cursor.getColumnName(i)
                    when (cursor.getType(i)) {
                        android.database.Cursor.FIELD_TYPE_INTEGER -> sObj.put(colName, cursor.getLong(i))
                        android.database.Cursor.FIELD_TYPE_FLOAT -> sObj.put(colName, cursor.getDouble(i))
                        android.database.Cursor.FIELD_TYPE_STRING -> sObj.put(colName, cursor.getString(i))
                        android.database.Cursor.FIELD_TYPE_NULL -> sObj.put(colName, JSONObject.NULL)
                    }
                }
                studentsArray.put(sObj)
            }
        }
        root.put("students", studentsArray)

        val attendanceArray = JSONArray()
        val att = database.openHelper.readableDatabase.query("SELECT * FROM attendance_records")
        att.use { cursor ->
            while (cursor.moveToNext()) {
                val aObj = JSONObject()
                for (i in 0 until cursor.columnCount) {
                    val colName = cursor.getColumnName(i)
                    when (cursor.getType(i)) {
                        android.database.Cursor.FIELD_TYPE_INTEGER -> aObj.put(colName, cursor.getLong(i))
                        android.database.Cursor.FIELD_TYPE_FLOAT -> aObj.put(colName, cursor.getDouble(i))
                        android.database.Cursor.FIELD_TYPE_STRING -> aObj.put(colName, cursor.getString(i))
                        android.database.Cursor.FIELD_TYPE_NULL -> aObj.put(colName, JSONObject.NULL)
                    }
                }
                attendanceArray.put(aObj)
            }
        }
        root.put("attendance_records", attendanceArray)

        root.toString(2)
    }

    suspend fun restoreDatabaseFromJson(jsonString: String, adminUser: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val studentsArray = root.optJSONArray("students") ?: JSONArray()
            val attendanceArray = root.optJSONArray("attendance_records") ?: JSONArray()

            var restoredStudents = 0
            for (i in 0 until studentsArray.length()) {
                val obj = studentsArray.getJSONObject(i)
                val regNo = obj.optString("registrationNumber")
                if (regNo.isNotBlank()) {
                    val student = StudentEntity(
                        fullName = obj.optString("fullName"),
                        registrationNumber = regNo,
                        studentIdNumber = obj.optString("studentIdNumber", "ECU-$regNo"),
                        faculty = obj.optString("faculty"),
                        department = obj.optString("department"),
                        course = obj.optString("course"),
                        academicYear = obj.optString("academicYear", "2025/2026"),
                        academicLevel = obj.optString("academicLevel", "Year 2"),
                        biometricTemplate = if (obj.has("biometricTemplate") && !obj.isNull("biometricTemplate")) obj.getString("biometricTemplate") else null,
                        biometricFingerType = obj.optString("biometricFingerType", "Right Thumb"),
                        isBiometricRegistered = obj.optBoolean("isBiometricRegistered", false),
                        photoPath = if (obj.has("photoPath") && !obj.isNull("photoPath")) obj.getString("photoPath") else null
                    )
                    studentDao.insertStudent(student)
                    restoredStudents++
                }
            }

            for (i in 0 until attendanceArray.length()) {
                val obj = attendanceArray.getJSONObject(i)
                val record = AttendanceRecordEntity(
                    studentId = obj.optLong("studentId", 0L),
                    studentRegistrationNumber = obj.optString("studentRegistrationNumber"),
                    studentFullName = obj.optString("studentFullName"),
                    dateString = obj.optString("dateString"),
                    dayOfWeek = obj.optString("dayOfWeek", "Monday"),
                    sessionName = obj.optString("sessionName", "Morning Session"),
                    course = obj.optString("course"),
                    academicLevel = obj.optString("academicLevel"),
                    academicYear = obj.optString("academicYear", "2025/2026"),
                    status = obj.optString("status", "PRESENT"),
                    verificationMethod = obj.optString("verificationMethod", "BIOMETRIC_THUMBPRINT"),
                    verifiedTimestamp = obj.optLong("verifiedTimestamp", System.currentTimeMillis()),
                    verifiedTimeFormatted = obj.optString("verifiedTimeFormatted", "08:30 AM"),
                    markedByAdmin = obj.optString("markedByAdmin", adminUser),
                    correctionReason = if (obj.has("correctionReason") && !obj.isNull("correctionReason")) obj.getString("correctionReason") else null
                )
                attendanceDao.insertAttendanceRecord(record)
            }

            addAuditLog(
                actionType = "DATABASE_RESTORE",
                admin = adminUser,
                details = "Restored database snapshot containing $restoredStudents students and ${attendanceArray.length()} attendance entries"
            )

            Result.success(restoredStudents)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Seeds initial ECU university programs, classes, and realistic students
     * (including 24/BBA/006, 24/BBA/007, etc.) if the database is newly initialized.
     */
    suspend fun seedInitialEcuDataIfNeeded() = withContext(Dispatchers.IO) {
        val count = database.openHelper.readableDatabase.query("SELECT COUNT(*) FROM students").use { cursor ->
            if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }

        if (count == 0) {
            // Seed Academic Programs
            val programs = listOf(
                AcademicProgramEntity(
                    faculty = "Faculty of Business Administration",
                    department = "Department of Management & Accounting",
                    programmeName = "Bachelor of Business Administration",
                    programmeCode = "BBA",
                    levels = "Year 1,Year 2,Year 3,Year 4",
                    academicYear = "2025/2026",
                    description = "Comprehensive undergraduate business leadership & commerce program"
                ),
                AcademicProgramEntity(
                    faculty = "Faculty of Science & Technology",
                    department = "Department of Computer Science & IT",
                    programmeName = "Bachelor of Science in Information Technology",
                    programmeCode = "BSc IT",
                    levels = "Year 1,Year 2,Year 3,Year 4",
                    academicYear = "2025/2026",
                    description = "Software systems, networking, databases and cyber infrastructure"
                ),
                AcademicProgramEntity(
                    faculty = "Faculty of Education",
                    department = "Department of Curriculum & Foundations",
                    programmeName = "Bachelor of Education (Arts)",
                    programmeCode = "BED Arts",
                    levels = "Year 1,Year 2,Year 3,Year 4",
                    academicYear = "2025/2026",
                    description = "Teacher education training across social sciences & languages"
                ),
                AcademicProgramEntity(
                    faculty = "Faculty of Theology & Leadership",
                    department = "Department of Biblical Studies",
                    programmeName = "Bachelor of Theology",
                    programmeCode = "BTH",
                    levels = "Year 1,Year 2,Year 3,Year 4",
                    academicYear = "2025/2026",
                    description = "Christian ministry, pastoral leadership, and biblical hermeneutics"
                )
            )
            programDao.insertPrograms(programs)

            // Seed Sample Students with registered biometric templates
            val sampleStudents = listOf(
                StudentEntity(
                    fullName = "Emmanuel Deng Garang",
                    registrationNumber = "24/BBA/006",
                    studentIdNumber = "ECU-STD-2024-006",
                    faculty = "Faculty of Business Administration",
                    department = "Department of Management & Accounting",
                    course = "Bachelor of Business Administration",
                    academicYear = "2025/2026",
                    academicLevel = "Year 2",
                    gender = "Male",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("24/BBA/006", "Right Thumb", 98)
                ),
                StudentEntity(
                    fullName = "Grace Akech Kuol",
                    registrationNumber = "24/BBA/007",
                    studentIdNumber = "ECU-STD-2024-007",
                    faculty = "Faculty of Business Administration",
                    department = "Department of Management & Accounting",
                    course = "Bachelor of Business Administration",
                    academicYear = "2025/2026",
                    academicLevel = "Year 2",
                    gender = "Female",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("24/BBA/007", "Right Thumb", 95)
                ),
                StudentEntity(
                    fullName = "John Lado Kenyi",
                    registrationNumber = "24/BBA/008",
                    studentIdNumber = "ECU-STD-2024-008",
                    faculty = "Faculty of Business Administration",
                    department = "Department of Management & Accounting",
                    course = "Bachelor of Business Administration",
                    academicYear = "2025/2026",
                    academicLevel = "Year 2",
                    gender = "Male",
                    isBiometricRegistered = true,
                    biometricFingerType = "Left Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("24/BBA/008", "Left Thumb", 92)
                ),
                StudentEntity(
                    fullName = "Sarah Mary Peter",
                    registrationNumber = "24/BBA/009",
                    studentIdNumber = "ECU-STD-2024-009",
                    faculty = "Faculty of Business Administration",
                    department = "Department of Management & Accounting",
                    course = "Bachelor of Business Administration",
                    academicYear = "2025/2026",
                    academicLevel = "Year 2",
                    gender = "Female",
                    isBiometricRegistered = false,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = null
                ),
                StudentEntity(
                    fullName = "David Taban James",
                    registrationNumber = "23/BScIT/014",
                    studentIdNumber = "ECU-STD-2023-014",
                    faculty = "Faculty of Science & Technology",
                    department = "Department of Computer Science & IT",
                    course = "Bachelor of Science in Information Technology",
                    academicYear = "2025/2026",
                    academicLevel = "Year 3",
                    gender = "Male",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Index",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("23/BScIT/014", "Right Index", 97)
                ),
                StudentEntity(
                    fullName = "Rebecca Nyalong Paul",
                    registrationNumber = "23/BScIT/015",
                    studentIdNumber = "ECU-STD-2023-015",
                    faculty = "Faculty of Science & Technology",
                    department = "Department of Computer Science & IT",
                    course = "Bachelor of Science in Information Technology",
                    academicYear = "2025/2026",
                    academicLevel = "Year 3",
                    gender = "Female",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("23/BScIT/015", "Right Thumb", 94)
                ),
                StudentEntity(
                    fullName = "Joseph Wani Thomas",
                    registrationNumber = "25/BED/002",
                    studentIdNumber = "ECU-STD-2025-002",
                    faculty = "Faculty of Education",
                    department = "Department of Curriculum & Foundations",
                    course = "Bachelor of Education (Arts)",
                    academicYear = "2025/2026",
                    academicLevel = "Year 1",
                    gender = "Male",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("25/BED/002", "Right Thumb", 91)
                ),
                StudentEntity(
                    fullName = "Agnes Kiden Simon",
                    registrationNumber = "25/BTH/005",
                    studentIdNumber = "ECU-STD-2025-005",
                    faculty = "Faculty of Theology & Leadership",
                    department = "Department of Biblical Studies",
                    course = "Bachelor of Theology",
                    academicYear = "2025/2026",
                    academicLevel = "Year 1",
                    gender = "Female",
                    isBiometricRegistered = true,
                    biometricFingerType = "Right Thumb",
                    biometricTemplate = biometricHardwareManager.generateBiometricTemplate("25/BTH/005", "Right Thumb", 96)
                )
            )

            studentDao.insertStudents(sampleStudents)

            // Seed initial attendance records for the current week working days (Mon-Fri)
            val cal = Calendar.getInstance()
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val todayStr = dateFormat.format(cal.time)

            val initialAttendance = listOf(
                AttendanceRecordEntity(
                    studentId = 1,
                    studentRegistrationNumber = "24/BBA/006",
                    studentFullName = "Emmanuel Deng Garang",
                    dateString = todayStr,
                    dayOfWeek = SimpleDateFormat("EEEE", Locale.getDefault()).format(cal.time),
                    sessionName = "Morning Session",
                    course = "Bachelor of Business Administration",
                    academicLevel = "Year 2",
                    academicYear = "2025/2026",
                    status = "PRESENT",
                    verificationMethod = "BIOMETRIC_THUMBPRINT",
                    verifiedTimestamp = System.currentTimeMillis() - 3600000,
                    verifiedTimeFormatted = "08:15:20 AM",
                    markedByAdmin = "ECU Biometric Scanner"
                ),
                AttendanceRecordEntity(
                    studentId = 2,
                    studentRegistrationNumber = "24/BBA/007",
                    studentFullName = "Grace Akech Kuol",
                    dateString = todayStr,
                    dayOfWeek = SimpleDateFormat("EEEE", Locale.getDefault()).format(cal.time),
                    sessionName = "Morning Session",
                    course = "Bachelor of Business Administration",
                    academicLevel = "Year 2",
                    academicYear = "2025/2026",
                    status = "PRESENT",
                    verificationMethod = "BIOMETRIC_THUMBPRINT",
                    verifiedTimestamp = System.currentTimeMillis() - 1800000,
                    verifiedTimeFormatted = "08:32:45 AM",
                    markedByAdmin = "ECU Biometric Scanner"
                )
            )
            attendanceDao.insertAttendanceRecords(initialAttendance)

            addAuditLog(
                actionType = "SYSTEM_INITIALIZED",
                admin = "System",
                details = "ECU DATA ATTENDANCE database initialized with standard academic programs and sample student records"
            )
        }
    }
}
