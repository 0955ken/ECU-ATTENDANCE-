package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AcademicProgramEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AcademicProgramDao {
    @Query("SELECT * FROM academic_programs ORDER BY faculty ASC, programmeName ASC")
    fun getAllPrograms(): Flow<List<AcademicProgramEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgram(program: AcademicProgramEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrograms(programs: List<AcademicProgramEntity>): List<Long>

    @Update
    suspend fun updateProgram(program: AcademicProgramEntity)

    @Delete
    suspend fun deleteProgram(program: AcademicProgramEntity)

    @Query("DELETE FROM academic_programs WHERE id = :id")
    suspend fun deleteProgramById(id: Long)

    @Query("SELECT COUNT(*) FROM academic_programs")
    suspend fun getProgramCount(): Int
}
