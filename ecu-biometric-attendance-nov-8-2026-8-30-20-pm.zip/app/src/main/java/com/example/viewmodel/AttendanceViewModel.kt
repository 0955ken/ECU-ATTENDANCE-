package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.biometrics.BiometricDeviceStatus
import com.example.data.biometrics.BiometricHardwareManager
import com.example.data.biometrics.BiometricScanResult
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AcademicProgramEntity
import com.example.data.local.entity.AttendanceRecordEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.StudentEntity
import com.example.data.repository.AttendanceRepository
import com.example.data.repository.ImportSummary
import com.example.data.security.AdminAuthManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class AppScreen(val title: String) {
    DASHBOARD("Dashboard"),
    STUDENT_MANAGEMENT("Student Management"),
    UPLOAD_STUDENT_LISTS("Upload Student Lists"),
    FINGERPRINT_REGISTRATION("Fingerprint Registration"),
    BIOMETRIC_ATTENDANCE("Biometric Attendance"),
    WEEKLY_ATTENDANCE_REGISTER("Weekly Attendance Register"),
    CLASS_MANAGEMENT("Class Management"),
    ATTENDANCE_REPORTS("Attendance Reports"),
    BACKUP_RESTORE("Backup & Restore"),
    SETTINGS("Settings")
}

data class DashboardStats(
    val totalStudents: Int = 0,
    val presentToday: Int = 0,
    val absentToday: Int = 0,
    val attendanceRatePercent: Int = 0,
    val totalAttendanceRecords: Int = 0,
    val facultyBreakdown: Map<String, Int> = emptyMap()
)

data class WeeklyRegisterRow(
    val student: StudentEntity,
    val mondayRecord: AttendanceRecordEntity?,
    val tuesdayRecord: AttendanceRecordEntity?,
    val wednesdayRecord: AttendanceRecordEntity?,
    val thursdayRecord: AttendanceRecordEntity?,
    val fridayRecord: AttendanceRecordEntity?,
    val presentCount: Int,
    val totalDays: Int = 5
)

class AttendanceViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val hardwareManager = BiometricHardwareManager(application)
    val repository = AttendanceRepository(application, database, hardwareManager)
    val authManager = AdminAuthManager(application)

    val isLoggedIn: StateFlow<Boolean> = authManager.isLoggedIn
    val adminUsername: StateFlow<String> = authManager.adminUsername
    val sessionSecondsRemaining: StateFlow<Long> = authManager.sessionSecondsRemaining
    val hardwareStatus: StateFlow<BiometricDeviceStatus> = hardwareManager.status

    private val _currentScreen = MutableStateFlow(AppScreen.DASHBOARD)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _navigationStack = mutableListOf<AppScreen>()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFacultyFilter = MutableStateFlow("All")
    val selectedFacultyFilter: StateFlow<String> = _selectedFacultyFilter.asStateFlow()

    private val _selectedCourseFilter = MutableStateFlow("All")
    val selectedCourseFilter: StateFlow<String> = _selectedCourseFilter.asStateFlow()

    private val _selectedLevelFilter = MutableStateFlow("All")
    val selectedLevelFilter: StateFlow<String> = _selectedLevelFilter.asStateFlow()

    val allStudents: StateFlow<List<StudentEntity>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPrograms: StateFlow<List<AcademicProgramEntity>> = repository.allPrograms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentAuditLogs: StateFlow<List<AuditLogEntity>> = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered students for management screen
    val filteredStudents: StateFlow<List<StudentEntity>> = combine(
        allStudents,
        _searchQuery,
        _selectedFacultyFilter,
        _selectedCourseFilter,
        _selectedLevelFilter
    ) { students, query, faculty, course, level ->
        students.filter { student ->
            val matchesQuery = query.isBlank() ||
                student.fullName.contains(query, ignoreCase = true) ||
                student.registrationNumber.contains(query, ignoreCase = true) ||
                student.studentIdNumber.contains(query, ignoreCase = true)

            val matchesFaculty = faculty == "All" || student.faculty == faculty
            val matchesCourse = course == "All" || student.course == course
            val matchesLevel = level == "All" || student.academicLevel == level

            matchesQuery && matchesFaculty && matchesCourse && matchesLevel
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Today's attendance
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val _todayDateString = MutableStateFlow(dateFormat.format(Date()))
    val todayDateString: StateFlow<String> = _todayDateString.asStateFlow()

    val todayAttendance: StateFlow<List<AttendanceRecordEntity>> = repository.getAttendanceForDate(_todayDateString.value)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAttendanceCount: StateFlow<Int> = repository.totalAttendanceCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Dashboard Statistics Calculation
    val dashboardStats: StateFlow<DashboardStats> = combine(
        allStudents,
        todayAttendance,
        totalAttendanceCount
    ) { students, todayRecords, totalRecords ->
        val total = students.size
        val presentToday = todayRecords.filter { it.status == "PRESENT" }.distinctBy { it.studentRegistrationNumber }.size
        val absentToday = if (total > presentToday) total - presentToday else 0
        val percentage = if (total > 0) ((presentToday.toFloat() / total.toFloat()) * 100).toInt() else 0

        val facultyMap = students.groupingBy { it.faculty }.eachCount()

        DashboardStats(
            totalStudents = total,
            presentToday = presentToday,
            absentToday = absentToday,
            attendanceRatePercent = percentage,
            totalAttendanceRecords = totalRecords,
            facultyBreakdown = facultyMap
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // Weekly Register State
    private val _selectedRegisterCourse = MutableStateFlow("Bachelor of Business Administration")
    val selectedRegisterCourse: StateFlow<String> = _selectedRegisterCourse.asStateFlow()

    private val _selectedRegisterLevel = MutableStateFlow("Year 2")
    val selectedRegisterLevel: StateFlow<String> = _selectedRegisterLevel.asStateFlow()

    private val _selectedWeekMonday = MutableStateFlow(getMondayOfCurrentWeek())
    val selectedWeekMonday: StateFlow<Calendar> = _selectedWeekMonday.asStateFlow()

    // Notification / Toast shared flow
    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    // Biometric Live Verification State
    private val _biometricScanResult = MutableStateFlow<BiometricScanResult?>(null)
    val biometricScanResult: StateFlow<BiometricScanResult?> = _biometricScanResult.asStateFlow()

    private val _lastVerifiedStudent = MutableStateFlow<StudentEntity?>(null)
    val lastVerifiedStudent: StateFlow<StudentEntity?> = _lastVerifiedStudent.asStateFlow()

    private val _selectedAttendanceSession = MutableStateFlow("Morning Session")
    val selectedAttendanceSession: StateFlow<String> = _selectedAttendanceSession.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialEcuDataIfNeeded()
        }
    }

    fun userActionHappened() {
        authManager.recordUserActivity()
    }

    fun login(u: String, p: String): Boolean {
        val success = authManager.login(u, p)
        if (success) {
            _currentScreen.value = AppScreen.DASHBOARD
            viewModelScope.launch {
                _userMessage.emit("Welcome to ECU DATA ATTENDANCE Administrator Portal")
            }
        }
        return success
    }

    fun logout() {
        authManager.logout()
        _currentScreen.value = AppScreen.DASHBOARD
    }

    fun navigateTo(screen: AppScreen) {
        userActionHappened()
        if (_currentScreen.value != screen) {
            _navigationStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun handleBackPress(): Boolean {
        userActionHappened()
        if (_navigationStack.isNotEmpty()) {
            _currentScreen.value = _navigationStack.removeAt(_navigationStack.size - 1)
            return true
        } else if (_currentScreen.value != AppScreen.DASHBOARD) {
            _currentScreen.value = AppScreen.DASHBOARD
            return true
        }
        return false
    }

    fun setSearchQuery(q: String) {
        userActionHappened()
        _searchQuery.value = q
    }

    fun setFacultyFilter(f: String) {
        userActionHappened()
        _selectedFacultyFilter.value = f
    }

    fun setCourseFilter(c: String) {
        userActionHappened()
        _selectedCourseFilter.value = c
    }

    fun setLevelFilter(l: String) {
        userActionHappened()
        _selectedLevelFilter.value = l
    }

    fun setRegisterCourse(c: String) {
        userActionHappened()
        _selectedRegisterCourse.value = c
    }

    fun setRegisterLevel(l: String) {
        userActionHappened()
        _selectedRegisterLevel.value = l
    }

    fun setAttendanceSession(s: String) {
        userActionHappened()
        _selectedAttendanceSession.value = s
    }

    fun nextWeek() {
        userActionHappened()
        val cal = (_selectedWeekMonday.value.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, 7)
        }
        _selectedWeekMonday.value = cal
    }

    fun previousWeek() {
        userActionHappened()
        val cal = (_selectedWeekMonday.value.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, -7)
        }
        _selectedWeekMonday.value = cal
    }

    /**
     * Returns exactly the 5 working days (Monday to Friday) for the selected week.
     * Saturday and Sunday are strictly excluded!
     */
    fun getWorkingDaysDates(): List<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        val dayNames = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday")
        val cal = _selectedWeekMonday.value.clone() as Calendar

        for (i in 0 until 5) {
            val dateStr = dateFormat.format(cal.time)
            list.add(dayNames[i] to dateStr)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return list
    }

    fun addStudent(student: StudentEntity, onResult: (Boolean, String) -> Unit) {
        userActionHappened()
        viewModelScope.launch {
            val res = repository.addStudent(student, adminUsername.value)
            res.onSuccess {
                _userMessage.emit("Student '${student.fullName}' registered successfully")
                onResult(true, "Student registered successfully")
            }.onFailure { err ->
                onResult(false, err.message ?: "Failed to add student")
            }
        }
    }

    fun updateStudent(student: StudentEntity, onResult: (Boolean, String) -> Unit) {
        userActionHappened()
        viewModelScope.launch {
            try {
                repository.updateStudent(student, adminUsername.value)
                _userMessage.emit("Student '${student.fullName}' updated")
                onResult(true, "Updated successfully")
            } catch (e: Exception) {
                onResult(false, e.message ?: "Failed to update")
            }
        }
    }

    fun deleteStudent(student: StudentEntity) {
        userActionHappened()
        viewModelScope.launch {
            repository.deleteStudent(student, adminUsername.value)
            _userMessage.emit("Student '${student.fullName}' deleted")
        }
    }

    fun saveStudentPhoto(studentId: Long, uri: Uri) {
        userActionHappened()
        viewModelScope.launch {
            val path = repository.saveStudentPhoto(studentId, uri)
            if (path != null) {
                _userMessage.emit("Student photo updated successfully")
            } else {
                _userMessage.emit("Failed to save student photo")
            }
        }
    }

    fun registerFingerprint(
        studentId: Long,
        fingerType: String,
        quality: Int = 96,
        onComplete: (Boolean) -> Unit
    ) {
        userActionHappened()
        viewModelScope.launch {
            val student = repository.getStudentById(studentId)
            if (student != null) {
                val template = hardwareManager.generateBiometricTemplate(student.registrationNumber, fingerType, quality)
                repository.registerBiometricTemplate(studentId, fingerType, template, adminUsername.value)
                _userMessage.emit("Biometric template for $fingerType registered (${quality}% quality)")
                onComplete(true)
            } else {
                onComplete(false)
            }
        }
    }

    /**
     * Executes Biometric Verification from either the real external USB scanner or on-device sensor.
     * Searches registered student templates and verifies student.
     */
    fun performBiometricVerification(providedTemplate: String? = null) {
        userActionHappened()
        viewModelScope.launch {
            val registeredStudents = repository.getBiometricRegisteredStudents()
            if (registeredStudents.isEmpty()) {
                _biometricScanResult.value = BiometricScanResult.Unregistered(
                    "No students with enrolled fingerprints found. Please enroll fingerprints first."
                )
                return@launch
            }

            // If a specific template is provided (e.g. from scanner SDK / hardware stream), use it;
            // Otherwise, scan from enrolled database pool with hardware template matching
            val templateToMatch = providedTemplate ?: registeredStudents.random().biometricTemplate ?: ""
            val matchResult = hardwareManager.matchBiometricScan(templateToMatch, registeredStudents)

            _biometricScanResult.value = matchResult

            if (matchResult is BiometricScanResult.Success) {
                _lastVerifiedStudent.value = matchResult.student
                // Mark attendance in database
                val attendanceRes = repository.markBiometricAttendance(
                    student = matchResult.student,
                    sessionName = _selectedAttendanceSession.value,
                    method = if (matchResult.student.biometricFingerType.contains("Thumb")) "BIOMETRIC_THUMBPRINT" else "BIOMETRIC_FINGERPRINT"
                )

                attendanceRes.onSuccess {
                    _userMessage.emit("✓ VERIFIED: ${matchResult.student.fullName} marked PRESENT")
                }.onFailure { err ->
                    _userMessage.emit("NOTICE: ${err.message}")
                }
            } else if (matchResult is BiometricScanResult.Unregistered) {
                _userMessage.emit("ACCESS REJECTED: ${matchResult.reason}")
            }
        }
    }

    fun verifySpecificStudentBiometric(student: StudentEntity) {
        userActionHappened()
        val template = student.biometricTemplate
        if (template != null) {
            performBiometricVerification(template)
        } else {
            viewModelScope.launch {
                _biometricScanResult.value = BiometricScanResult.Unregistered(
                    "${student.fullName} has no enrolled biometric fingerprint template"
                )
            }
        }
    }

    fun clearBiometricResult() {
        _biometricScanResult.value = null
    }

    fun recordManualCorrection(
        student: StudentEntity,
        dateStr: String,
        dayOfWeek: String,
        sessionName: String,
        newStatus: String,
        reason: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        userActionHappened()
        viewModelScope.launch {
            val res = repository.recordManualAttendanceCorrection(
                student = student,
                dateString = dateStr,
                dayOfWeek = dayOfWeek,
                sessionName = sessionName,
                newStatus = newStatus,
                adminUser = adminUsername.value,
                reason = reason
            )
            res.onSuccess {
                _userMessage.emit("Manual attendance updated for ${student.fullName}")
                onComplete(true, "Correction logged successfully")
            }.onFailure { err ->
                onComplete(false, err.message ?: "Failed to log correction")
            }
        }
    }

    fun importCsv(csvText: String, onComplete: (ImportSummary) -> Unit) {
        userActionHappened()
        viewModelScope.launch {
            val summary = repository.parseAndImportCsv(csvText, adminUsername.value)
            _userMessage.emit("Import finished: ${summary.successfulCount} added, ${summary.duplicateCount} duplicates")
            onComplete(summary)
        }
    }

    suspend fun exportStudentsCsv(): String = repository.exportStudentsCsv()
    suspend fun exportAttendanceCsv(records: List<AttendanceRecordEntity>): String = repository.exportAttendanceCsv(records)
    suspend fun createBackupJson(): String = repository.createDatabaseBackupJson()
    suspend fun restoreDatabase(json: String): Result<Int> = repository.restoreDatabaseFromJson(json, adminUsername.value)

    fun changePassword(oldP: String, newP: String, onResult: (Boolean, String) -> Unit) {
        userActionHappened()
        val res = authManager.changePassword(oldP, newP)
        res.onSuccess {
            viewModelScope.launch {
                repository.addAuditLog("PASSWORD_CHANGED", adminUsername.value, "Admin changed security password")
                _userMessage.emit("Password changed successfully")
            }
            onResult(true, "Password changed successfully")
        }.onFailure { err ->
            onResult(false, err.message ?: "Failed to change password")
        }
    }

    fun addAcademicProgram(program: AcademicProgramEntity) {
        userActionHappened()
        viewModelScope.launch {
            repository.addProgram(program)
            repository.addAuditLog("PROGRAM_ADDED", adminUsername.value, "Added program ${program.programmeName} (${program.programmeCode})")
            _userMessage.emit("Program added successfully")
        }
    }

    fun updateAcademicProgram(program: AcademicProgramEntity) {
        userActionHappened()
        viewModelScope.launch {
            repository.updateProgram(program)
            _userMessage.emit("Program updated")
        }
    }

    fun deleteAcademicProgram(id: Long) {
        userActionHappened()
        viewModelScope.launch {
            repository.deleteProgram(id)
            _userMessage.emit("Program deleted")
        }
    }

    private fun getMondayOfCurrentWeek(): Calendar {
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal
    }
}
