package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.EcuAppBar
import com.example.ui.components.NavigationDrawerContent
import com.example.ui.screens.AttendanceReportsScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.BiometricAttendanceScreen
import com.example.ui.screens.ClassManagementScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FingerprintRegistrationScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudentManagementScreen
import com.example.ui.screens.UploadStudentListsScreen
import com.example.ui.screens.WeeklyAttendanceRegisterScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppEntry()
            }
        }
    }
}

@Composable
fun MainAppEntry(viewModel: AttendanceViewModel = viewModel()) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val adminUsername by viewModel.adminUsername.collectAsState()
    val secondsRemaining by viewModel.sessionSecondsRemaining.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.userMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    if (!isLoggedIn) {
        LoginScreen(
            onLoginSuccess = { user, pass ->
                viewModel.login(user, pass)
            }
        )
    } else {
        // Back press handling: close drawer if open, else pop screen stack to Dashboard
        BackHandler(enabled = true) {
            if (drawerState.isOpen) {
                scope.launch { drawerState.close() }
            } else {
                val handled = viewModel.handleBackPress()
                if (!handled) {
                    // At dashboard, do not exit directly or lock session
                }
            }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet {
                    NavigationDrawerContent(
                        currentScreen = currentScreen,
                        adminUser = adminUsername,
                        onSelectScreen = { screen ->
                            viewModel.navigateTo(screen)
                            scope.launch { drawerState.close() }
                        },
                        onLogout = {
                            viewModel.logout()
                            scope.launch { drawerState.close() }
                        }
                    )
                }
            }
        ) {
            Scaffold(
                topBar = {
                    EcuAppBar(
                        title = currentScreen.title,
                        adminUser = adminUsername,
                        secondsRemaining = secondsRemaining,
                        hardwareStatus = hardwareStatus,
                        onOpenNav = {
                            scope.launch { drawerState.open() }
                        },
                        onLockSession = {
                            viewModel.logout()
                        }
                    )
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentScreen) {
                        AppScreen.DASHBOARD -> DashboardScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.STUDENT_MANAGEMENT -> StudentManagementScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.UPLOAD_STUDENT_LISTS -> UploadStudentListsScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.FINGERPRINT_REGISTRATION -> FingerprintRegistrationScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.BIOMETRIC_ATTENDANCE -> BiometricAttendanceScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.WEEKLY_ATTENDANCE_REGISTER -> WeeklyAttendanceRegisterScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.CLASS_MANAGEMENT -> ClassManagementScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.ATTENDANCE_REPORTS -> AttendanceReportsScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.BACKUP_RESTORE -> BackupRestoreScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                        AppScreen.SETTINGS -> SettingsScreen(
                            viewModel = viewModel,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                }
            }
        }
    }
}
