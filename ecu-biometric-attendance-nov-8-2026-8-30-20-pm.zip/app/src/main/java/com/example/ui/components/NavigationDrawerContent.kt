package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuNavyLight
import com.example.viewmodel.AppScreen

data class NavMenuItem(
    val screen: AppScreen,
    val icon: ImageVector,
    val badge: String? = null
)

@Composable
fun NavigationDrawerContent(
    currentScreen: AppScreen,
    adminUser: String,
    onSelectScreen: (AppScreen) -> Unit,
    onLogout: () -> Unit
) {
    val menuItems = listOf(
        NavMenuItem(AppScreen.DASHBOARD, Icons.Default.Dashboard),
        NavMenuItem(AppScreen.STUDENT_MANAGEMENT, Icons.Default.People),
        NavMenuItem(AppScreen.UPLOAD_STUDENT_LISTS, Icons.Default.UploadFile),
        NavMenuItem(AppScreen.FINGERPRINT_REGISTRATION, Icons.Default.Fingerprint),
        NavMenuItem(AppScreen.BIOMETRIC_ATTENDANCE, Icons.Default.VerifiedUser),
        NavMenuItem(AppScreen.WEEKLY_ATTENDANCE_REGISTER, Icons.Default.HowToReg),
        NavMenuItem(AppScreen.CLASS_MANAGEMENT, Icons.Default.Class),
        NavMenuItem(AppScreen.ATTENDANCE_REPORTS, Icons.Default.Assessment),
        NavMenuItem(AppScreen.BACKUP_RESTORE, Icons.Default.Backup),
        NavMenuItem(AppScreen.SETTINGS, Icons.Default.Settings)
    )

    Surface(
        color = EcuNavy,
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
        ) {
            // Header: University Logo & Administrator Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(EcuNavyDark)
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(EcuNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ecu_logo),
                                contentDescription = "ECU Logo",
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "EMMANUEL CHRISTIAN",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuGoldLight,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "UNIVERSITY",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "ECU DATA ATTENDANCE",
                                fontSize = 10.sp,
                                color = EcuGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        color = EcuNavyLight,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Admin: $adminUser",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "OFFLINE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuGoldLight
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Navigation Items
            menuItems.forEachIndexed { index, item ->
                val isSelected = currentScreen == item.screen
                val itemBg = if (isSelected) EcuNavyLight else Color.Transparent
                val contentColor = if (isSelected) EcuGoldLight else Color.White.copy(alpha = 0.85f)
                val iconColor = if (isSelected) EcuGold else Color.White.copy(alpha = 0.7f)

                Surface(
                    color = itemBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                        .testTag("nav_item_${item.screen.name}")
                        .clickable { onSelectScreen(item.screen) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "${index + 1}.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = EcuGold.copy(alpha = 0.6f),
                            modifier = Modifier.width(22.dp)
                        )

                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.screen.title,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = item.screen.title,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = contentColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(modifier = Modifier.height(8.dp))

            // Logout Option
            Surface(
                color = Color.Transparent,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("nav_item_LOGOUT")
                    .clickable { onLogout() }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = "11.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFEF4444).copy(alpha = 0.6f),
                        modifier = Modifier.width(22.dp)
                    )

                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Logout",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(20.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = "Logout",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFEF4444)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
