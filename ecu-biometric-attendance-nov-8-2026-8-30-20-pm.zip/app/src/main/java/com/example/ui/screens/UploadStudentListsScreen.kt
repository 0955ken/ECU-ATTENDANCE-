package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ImportSummary
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@Composable
fun UploadStudentListsScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val sampleCsvTemplate = """Full Name,Registration Number,Faculty,Department,Course,Academic Year,Class Level,Student ID
Daniel Taban Taban,24/BBA/010,Faculty of Business Administration,Department of Management,Bachelor of Business Administration,2025/2026,Year 2,ECU-STD-2024-010
Ester Juan Paul,24/BBA/011,Faculty of Business Administration,Department of Management,Bachelor of Business Administration,2025/2026,Year 2,ECU-STD-2024-011
Moses Alier Deng,23/BScIT/020,Faculty of Science & Technology,Department of Computer Science & IT,Bachelor of Science in Information Technology,2025/2026,Year 3,ECU-STD-2023-020
Florence Kiden Kenyi,25/BED/015,Faculty of Education,Department of Curriculum,Bachelor of Education (Arts),2025/2026,Year 1,ECU-STD-2025-015"""

    var csvInputText by remember { mutableStateOf("") }
    var importResult by remember { mutableStateOf<ImportSummary?>(null) }
    var isProcessing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.UploadFile,
                contentDescription = null,
                tint = EcuNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Upload Student Lists",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "Batch import students from Microsoft Excel (.xlsx) or CSV files",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
            }
        }

        // Instructions Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CSV / Excel Format Specifications:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Column structure: Full Name, Registration Number, Faculty, Department, Course, Academic Year, Class Level, Student ID",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = { csvInputText = sampleCsvTemplate },
                        colors = ButtonDefaults.buttonColors(containerColor = EcuGold),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_load_sample_csv")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = EcuNavyDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Load Sample Template",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = EcuNavyDark
                        )
                    }

                    OutlinedButton(
                        onClick = { csvInputText = "" },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Clear Input", fontSize = 12.sp)
                    }
                }
            }
        }

        // CSV Input Field
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Paste CSV / Spreadsheet Data Below:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuTextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = csvInputText,
                    onValueChange = {
                        csvInputText = it
                        importResult = null
                    },
                    placeholder = { Text("Paste CSV rows or click 'Load Sample Template' above...") },
                    minLines = 8,
                    maxLines = 14,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EcuNavy,
                        unfocusedBorderColor = EcuBorder,
                        focusedContainerColor = Color(0xFFF8FAFC),
                        unfocusedContainerColor = Color(0xFFF8FAFC)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("csv_data_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (csvInputText.isNotBlank()) {
                            isProcessing = true
                            viewModel.importCsv(csvInputText) { summary ->
                                isProcessing = false
                                importResult = summary
                            }
                        }
                    },
                    enabled = csvInputText.isNotBlank() && !isProcessing,
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_process_csv_import")
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, tint = EcuGoldLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isProcessing) "Validating & Importing..." else "PROCESS & IMPORT STUDENTS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }
        }

        // Import Summary Report
        if (importResult != null) {
            val res = importResult!!
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Import Verification Summary",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Success", fontSize = 11.sp, color = Color(0xFF065F46), fontWeight = FontWeight.SemiBold)
                                Text("${res.successfulCount}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EcuSuccess)
                            }
                        }

                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Duplicates", fontSize = 11.sp, color = Color(0xFF92400E), fontWeight = FontWeight.SemiBold)
                                Text("${res.duplicateCount}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                            }
                        }

                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Failed", fontSize = 11.sp, color = Color(0xFF991B1B), fontWeight = FontWeight.SemiBold)
                                Text("${res.failedCount}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                            }
                        }
                    }

                    if (res.errorMessages.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Validation Notices & Duplicate Alerts:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFB45309)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        res.errorMessages.take(6).forEach { err ->
                            Text(
                                text = "• $err",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onNavigate(AppScreen.STUDENT_MANAGEMENT) },
                        colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("View Enrolled Students Directory")
                    }
                }
            }
        }
    }
}
