package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = EcuNavy,
    onPrimary = EcuSurface,
    primaryContainer = EcuNavyLight,
    onPrimaryContainer = EcuGoldLight,
    secondary = EcuGoldDark,
    onSecondary = EcuSurface,
    secondaryContainer = EcuGoldContainer,
    onSecondaryContainer = EcuGoldDark,
    tertiary = EcuBlue,
    onTertiary = EcuSurface,
    background = EcuBackground,
    onBackground = EcuTextPrimary,
    surface = EcuSurface,
    onSurface = EcuTextPrimary,
    surfaceVariant = EcuSurfaceVariant,
    onSurfaceVariant = EcuTextSecondary,
    outline = EcuBorder,
    error = EcuError,
    onError = EcuSurface,
    errorContainer = EcuErrorContainer,
    onErrorContainer = EcuErrorDark
)

private val DarkColorScheme = darkColorScheme(
    primary = EcuGold,
    onPrimary = EcuNavyDark,
    primaryContainer = EcuNavyLight,
    onPrimaryContainer = EcuGoldLight,
    secondary = EcuGoldLight,
    onSecondary = EcuNavyDark,
    secondaryContainer = EcuNavy,
    onSecondaryContainer = EcuGoldLight,
    tertiary = EcuBlueAccent,
    onTertiary = EcuSurface,
    background = EcuNavyDark,
    onBackground = EcuSurface,
    surface = EcuNavy,
    onSurface = EcuSurface,
    surfaceVariant = EcuNavyLight,
    onSurfaceVariant = EcuGoldContainer,
    outline = EcuBlue,
    error = EcuError,
    onError = EcuSurface,
    errorContainer = EcuErrorDark,
    onErrorContainer = EcuErrorContainer
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Default to clean, professional light ECU administrative theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.primary.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
