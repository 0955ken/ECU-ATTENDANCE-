package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuNavyLight
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel
import kotlinx.coroutines.launch

@Composable
fun BackupRestoreScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val recentAuditLogs by viewModel.recentAuditLogs.collectAsState()

    var backupContent by remember { mutableStateOf<String?>(null) }
    var restoreInputJson by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Backup,
                contentDescription = null,
                tint = EcuNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Backup & Local Data Security",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "Create local database snapshots and review audit logs",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
            }
        }

        // Snapshot Creation Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Database Snapshots & Disaster Recovery",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "All student biometric records, photos, and attendance logs are stored locally. Create regular snapshots to ensure zero data loss.",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color(0xFFD1FAE5),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage!!,
                            color = Color(0xFF065F46),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            scope.launch {
                                val json = viewModel.createBackupJson()
                                backupContent = json
                                statusMessage = "Backup snapshot created (${json.length} bytes)"
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "ECU_Attendance_Backup.json")
                                    putExtra(Intent.EXTRA_TEXT, json)
                                }
                                context.startActivity(Intent.createChooser(intent, "Save or Export ECU Database Backup"))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_create_backup")
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = EcuGoldLight, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create Backup", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showRestoreDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_open_restore_dialog")
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore Data", fontSize = 12.sp, color = EcuNavy, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Administrative Audit Trail Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Administrative Audit Trail Log",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
            }
            Text(
                text = "${recentAuditLogs.size} Events",
                fontSize = 11.sp,
                color = EcuGoldDark,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Audit Trail List
        if (recentAuditLogs.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("No administrative events recorded yet.", fontSize = 12.sp, color = EcuTextSecondary)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(recentAuditLogs) { log ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Surface(
                                color = if (log.actionType == "MANUAL_CORRECTION") Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = log.actionType,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (log.actionType == "MANUAL_CORRECTION") Color(0xFFB45309) else EcuNavy,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(log.details, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = EcuTextPrimary)
                                Text("Admin: ${log.performedBy} • ${log.formattedTimestamp}", fontSize = 10.sp, color = EcuTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    // Restore Database Modal
    if (showRestoreDialog) {
        var restoreError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Local Database", fontWeight = FontWeight.Bold, color = EcuNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Paste a valid ECU DATA ATTENDANCE JSON backup string below to restore student records and attendance tables.",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )

                    OutlinedTextField(
                        value = restoreInputJson,
                        onValueChange = { restoreInputJson = it },
                        placeholder = { Text("Paste JSON backup data here...") },
                        minLines = 6,
                        maxLines = 10,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (restoreError != null) {
                        Text(restoreError!!, color = Color(0xFFDC2626), fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreInputJson.isNotBlank()) {
                            scope.launch {
                                val res = viewModel.restoreDatabase(restoreInputJson)
                                res.onSuccess { count ->
                                    statusMessage = "Successfully restored $count student records from backup"
                                    showRestoreDialog = false
                                }.onFailure { err ->
                                    restoreError = err.message ?: "Failed to parse backup JSON"
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy)
                ) {
                    Text("Restore Database")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
