package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Badge
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.biometrics.BiometricDeviceStatus
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcuAppBar(
    title: String,
    adminUser: String,
    secondsRemaining: Long,
    hardwareStatus: BiometricDeviceStatus,
    onOpenNav: () -> Unit,
    onLockSession: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = EcuNavy,
            titleContentColor = Color.White,
            navigationIconContentColor = EcuGoldLight,
            actionIconContentColor = Color.White
        ),
        navigationIcon = {
            IconButton(
                onClick = onOpenNav,
                modifier = Modifier.testTag("app_bar_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Open Navigation Menu",
                    tint = EcuGoldLight
                )
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // University Crest / Logo
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(EcuNavyDark),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ecu_logo),
                        contentDescription = "ECU University Crest",
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ECU DATA ATTENDANCE",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "•",
                            color = EcuGold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = EcuGoldLight
                        )
                    }
                    Text(
                        text = "EMMANUEL CHRISTIAN UNIVERSITY • Offline Biometric System",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.75f)
                    )
                }
            }
        },
        actions = {
            // Hardware Status Pill
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (hardwareStatus.hasHardware) EcuNavyDark else Color(0xFF334155),
                modifier = Modifier.padding(end = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (hardwareStatus.deviceType == "USB_OTG_SCANNER") Icons.Default.Usb else Icons.Default.Fingerprint,
                        contentDescription = "Hardware Scanner Status",
                        tint = if (hardwareStatus.isReady) EcuSuccess else EcuGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (hardwareStatus.deviceType == "USB_OTG_SCANNER") "USB Scan" else "Biometric",
                        fontSize = 10.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Inactivity session timer badge & Lock button
            IconButton(
                onClick = onLockSession,
                modifier = Modifier.testTag("app_bar_lock_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock Session",
                        tint = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(20.dp)
                    )
                    val minutes = secondsRemaining / 60
                    val secs = secondsRemaining % 60
                    Text(
                        text = "%02d:%02d".format(minutes, secs),
                        fontSize = 9.sp,
                        color = EcuGoldLight
                    )
                }
            }
        }
    )
}
