package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudentEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldContainer
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FingerprintRegistrationScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val allStudents by viewModel.allStudents.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()

    var selectedStudent by remember(allStudents) {
        mutableStateOf(allStudents.firstOrNull { !it.isBiometricRegistered } ?: allStudents.firstOrNull())
    }
    var expandedDropdown by remember { mutableStateOf(false) }

    val fingerTypes = listOf(
        "Right Thumb", "Left Thumb",
        "Right Index", "Left Index",
        "Right Middle", "Left Middle"
    )
    var selectedFinger by remember { mutableStateOf("Right Thumb") }

    var isCapturing by remember { mutableStateOf(false) }
    var captureQuality by remember { mutableIntStateOf(96) }
    var enrollmentSuccess by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Fingerprint,
                contentDescription = null,
                tint = EcuNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Fingerprint Registration",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "Enroll student biometric thumbprint / fingerprint templates",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
            }
        }

        // Hardware Status Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (hardwareStatus.hasHardware) EcuNavy else Color(0xFF64748B)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (hardwareStatus.deviceType == "USB_OTG_SCANNER") Icons.Default.Usb else Icons.Default.Sensors,
                        contentDescription = null,
                        tint = EcuGoldLight,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Biometric Hardware Scanner",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                    Text(
                        text = hardwareStatus.deviceName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuTextPrimary
                    )
                }

                Surface(
                    color = if (hardwareStatus.isReady) Color(0xFFD1FAE5) else Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (hardwareStatus.isReady) "READY" else "STANDBY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hardwareStatus.isReady) Color(0xFF065F46) else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Student Selection Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Select Student for Biometric Enrollment:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Spacer(modifier = Modifier.height(8.dp))

                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = !expandedDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedStudent?.let { "${it.fullName} (${it.registrationNumber})" } ?: "No student selected",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("select_student_dropdown")
                    )

                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false }
                    ) {
                        allStudents.forEach { student ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        StudentPhotoView(
                                            photoPath = student.photoPath,
                                            fullName = student.fullName,
                                            size = 28.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(student.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("${student.registrationNumber} • ${student.course}", fontSize = 11.sp, color = EcuTextSecondary)
                                        }
                                        Spacer(modifier = Modifier.weight(1f))
                                        if (student.isBiometricRegistered) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "Registered", tint = EcuSuccess, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                onClick = {
                                    selectedStudent = student
                                    expandedDropdown = false
                                    enrollmentSuccess = false
                                }
                            )
                        }
                    }
                }

                if (selectedStudent != null) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        StudentPhotoView(
                            photoPath = selectedStudent!!.photoPath,
                            fullName = selectedStudent!!.fullName,
                            size = 56.dp,
                            canEdit = true,
                            onPhotoSelected = { uri ->
                                viewModel.saveStudentPhoto(selectedStudent!!.id, uri)
                            }
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(selectedStudent!!.fullName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                            Text("Reg No: ${selectedStudent!!.registrationNumber}", fontSize = 12.sp, color = EcuNavy, fontWeight = FontWeight.SemiBold)
                            Text("${selectedStudent!!.course} • ${selectedStudent!!.academicLevel}", fontSize = 11.sp, color = EcuTextSecondary)
                            Text("ID: ${selectedStudent!!.studentIdNumber}", fontSize = 11.sp, color = Color(0xFF64748B))
                        }
                    }
                }
            }
        }

        // Finger Selection Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Select Finger / Thumb to Register:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    fingerTypes.take(3).forEach { finger ->
                        val isSelected = selectedFinger == finger
                        Surface(
                            color = if (isSelected) EcuNavy else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedFinger = finger }
                        ) {
                            Text(
                                text = finger,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else EcuTextPrimary,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    fingerTypes.drop(3).forEach { finger ->
                        val isSelected = selectedFinger == finger
                        Surface(
                            color = if (isSelected) EcuNavy else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedFinger = finger }
                        ) {
                            Text(
                                text = finger,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else EcuTextPrimary,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Biometric Scanner Capture Console
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Scanner Capture Console",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "Place student's $selectedFinger firmly on the biometric glass prism",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Scanner target with pulse effect during capture
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(if (isCapturing) pulseScale else 1f)
                        .clip(CircleShape)
                        .background(if (enrollmentSuccess) Color(0xFFD1FAE5) else if (isCapturing) EcuGoldContainer else Color(0xFFF1F5F9))
                        .border(
                            width = 3.dp,
                            color = if (enrollmentSuccess) EcuSuccess else if (isCapturing) EcuGold else EcuNavy,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (enrollmentSuccess) Icons.Default.Verified else Icons.Default.Fingerprint,
                        contentDescription = "Fingerprint Sensor",
                        tint = if (enrollmentSuccess) EcuSuccess else if (isCapturing) EcuGoldDark else EcuNavy,
                        modifier = Modifier.size(62.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isCapturing) {
                    Text(
                        text = "Extracting ISO/IEC 19794-2 minutiae features...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EcuGoldDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = EcuGold
                    )
                } else if (enrollmentSuccess) {
                    Text(
                        text = "✓ Biometric Enrolled Successfully ($captureQuality% Quality)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuSuccess
                    )
                    Text(
                        text = "Template saved locally for $selectedFinger",
                        fontSize = 11.sp,
                        color = EcuTextSecondary
                    )
                } else {
                    Text(
                        text = "Sensor Status: Standby for touch",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (selectedStudent != null) {
                            isCapturing = true
                            enrollmentSuccess = false
                            val quality = (92..99).random()
                            captureQuality = quality
                            viewModel.registerFingerprint(
                                studentId = selectedStudent!!.id,
                                fingerType = selectedFinger,
                                quality = quality
                            ) { ok ->
                                isCapturing = false
                                enrollmentSuccess = ok
                            }
                        }
                    },
                    enabled = selectedStudent != null && !isCapturing,
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_capture_fingerprint")
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, tint = EcuGoldLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCapturing) "CAPTURING..." else "CAPTURE & ENROLL $selectedFinger",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
