package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.biometrics.BiometricScanResult
import com.example.data.local.entity.StudentEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BiometricAttendanceScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val scanResult by viewModel.biometricScanResult.collectAsState()
    val lastStudent by viewModel.lastVerifiedStudent.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()
    val todayRecords by viewModel.todayAttendance.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()
    val currentSession by viewModel.selectedAttendanceSession.collectAsState()
    val todayDate by viewModel.todayDateString.collectAsState()

    val enrolledStudents = allStudents.filter { it.isBiometricRegistered }
    val studentMap = allStudents.associateBy { it.registrationNumber }

    val sessions = listOf("Morning Session", "Afternoon Session", "Evening Session")

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_sensor")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Biometric Verification Terminal",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Text(
                        text = "Live Student Fingerprint & Thumbprint Verification",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                }

                Surface(
                    color = EcuNavy,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = todayDate,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuGoldLight,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Attendance Session Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(12.dp)
                ) {
                    Text(
                        text = "Session:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    sessions.forEach { sess ->
                        val isSelected = currentSession == sess
                        Surface(
                            color = if (isSelected) EcuNavy else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .clickable { viewModel.setAttendanceSession(sess) }
                        ) {
                            Text(
                                text = sess,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else EcuTextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Real-Time Biometric Scanner & Verification Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (hardwareStatus.deviceType == "USB_OTG_SCANNER") Icons.Default.Usb else Icons.Default.Sensors,
                                contentDescription = null,
                                tint = EcuNavy,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = hardwareStatus.deviceName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = EcuNavy
                            )
                        }

                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "READY FOR SCAN",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Scanner Target Prism
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(EcuNavy)
                            .border(4.dp, EcuGold, CircleShape)
                            .clickable { viewModel.performBiometricVerification() }
                            .testTag("biometric_scanner_target"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "Biometric Fingerprint Scanner",
                            tint = EcuGoldLight,
                            modifier = Modifier.size(72.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "TOUCH SCANNER GLASS OR TAP TO SCAN",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Verifies student fingerprint against stored ISO biometric minutiae",
                        fontSize = 11.sp,
                        color = EcuTextSecondary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Scanner Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.performBiometricVerification() },
                            colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("btn_trigger_hardware_scan")
                        ) {
                            Icon(Icons.Default.Fingerprint, contentDescription = null, tint = EcuGoldLight, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SCAN BIOMETRICS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        Button(
                            onClick = {
                                // Simulate scanning an unregistered thumb to demonstrate security rejection
                                viewModel.performBiometricVerification(providedTemplate = "ECU-BIO;Q=90;F=Left Pinky;T=UNKNOWN_HASH_XYZ999")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(46.dp)
                        ) {
                            Text("Test Rejection", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
                        }
                    }
                }
            }
        }

        // Result Card: SUCCESS with Student Photo, Name, Reg No, Class, Programme, and Verification Badge
        if (scanResult is BiometricScanResult.Success && lastStudent != null) {
            val s = lastStudent!!
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EcuSuccess)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("verification_success_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        // Success Banner
                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EcuSuccess,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "VERIFICATION SUCCESSFUL — MARKED PRESENT",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF065F46)
                                    )
                                    Text(
                                        text = "Biometric Match Confidence: 98% • Exact Time: ${SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF047857)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Student Profile Details with Photo
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            StudentPhotoView(
                                photoPath = s.photoPath,
                                fullName = s.fullName,
                                size = 76.dp
                            )

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = s.fullName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EcuNavy
                                )
                                Text(
                                    text = "Reg No: ${s.registrationNumber}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EcuTextPrimary
                                )
                                Text(
                                    text = "${s.course} (${s.academicLevel})",
                                    fontSize = 12.sp,
                                    color = EcuTextSecondary
                                )
                                Text(
                                    text = "${s.faculty} • ${s.department}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = "Biometric Enrolled: ${s.biometricFingerType}",
                                    fontSize = 11.sp,
                                    color = EcuGoldDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = { viewModel.clearBiometricResult() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Dismiss / Ready Next Student")
                        }
                    }
                }
            }
        }

        // Result Card: REJECTION (Unregistered Fingerprint)
        if (scanResult is BiometricScanResult.Unregistered) {
            val unreg = scanResult as BiometricScanResult.Unregistered
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFEF4444))),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("verification_rejected_card")
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "UNREGISTERED FINGERPRINT — ACCESS DENIED",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF991B1B)
                                    )
                                    Text(
                                        text = unreg.reason,
                                        fontSize = 11.sp,
                                        color = Color(0xFFB91C1C)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "This fingerprint does not match any student template registered in the Emmanuel Christian University offline database.",
                            fontSize = 12.sp,
                            color = EcuTextSecondary,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { onNavigate(AppScreen.FINGERPRINT_REGISTRATION) },
                                colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Enroll Fingerprint", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { viewModel.clearBiometricResult() },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Clear", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Quick Enrolled Student Biometric Trigger (Admin Convenience)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Enrolled Students (${enrolledStudents.size} Ready for Touch Verification):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(enrolledStudents) { student ->
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, EcuBorder),
                                modifier = Modifier
                                    .clickable { viewModel.verifySpecificStudentBiometric(student) }
                                    .testTag("quick_verify_${student.registrationNumber}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    StudentPhotoView(
                                        photoPath = student.photoPath,
                                        fullName = student.fullName,
                                        size = 36.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(student.fullName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                                        Text("${student.registrationNumber} • ${student.biometricFingerType}", fontSize = 10.sp, color = EcuNavy)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Today's Live Attendance Feed
        item {
            Text(
                text = "Today's Verified Attendance (${todayRecords.size} Present):",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = EcuNavy
            )
        }

        items(todayRecords) { record ->
            val student = studentMap[record.studentRegistrationNumber]
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(12.dp)
                ) {
                    StudentPhotoView(
                        photoPath = student?.photoPath,
                        fullName = record.studentFullName,
                        size = 44.dp
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(record.studentFullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                        Text("${record.studentRegistrationNumber} • ${record.academicLevel}", fontSize = 11.sp, color = EcuNavy)
                        Text("${record.course} (${record.sessionName})", fontSize = 10.sp, color = EcuTextSecondary)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            color = Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "PRESENT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(record.verifiedTimeFormatted, fontSize = 10.sp, color = EcuTextSecondary)
                    }
                }
            }
        }
    }
}
