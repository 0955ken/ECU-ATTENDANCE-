package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AttendanceRecordEntity
import com.example.data.local.entity.StudentEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class CellCorrectionTarget(
    val student: StudentEntity,
    val dayName: String,
    val dateString: String,
    val currentRecord: AttendanceRecordEntity?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyAttendanceRegisterScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val selectedCourse by viewModel.selectedRegisterCourse.collectAsState()
    val selectedLevel by viewModel.selectedRegisterLevel.collectAsState()
    val selectedWeekMonday by viewModel.selectedWeekMonday.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()
    val distinctCourses = remember(allStudents) {
        val list = allStudents.map { it.course }.distinct().filter { it.isNotBlank() }
        if (list.isEmpty()) listOf("Bachelor of Business Administration", "Bachelor of Science in Information Technology", "Bachelor of Education (Arts)", "Bachelor of Theology") else list
    }
    val distinctLevels = remember(allStudents) {
        val list = allStudents.map { it.academicLevel }.distinct().filter { it.isNotBlank() }
        if (list.isEmpty()) listOf("Year 1", "Year 2", "Year 3", "Year 4") else list
    }

    // 5 Working days (Monday to Friday) strictly! Saturday & Sunday never appear
    val workingDays = viewModel.getWorkingDaysDates() // List<Pair<DayName, DateString>> (size 5)
    val workingDateStrings = workingDays.map { it.second }

    // Fetch weekly attendance records for this course & level
    val weekAttendanceRecords by viewModel.repository.getAttendanceForCourseLevelDates(
        course = selectedCourse,
        level = selectedLevel,
        dates = workingDateStrings
    ).collectAsState(initial = emptyList())

    val classStudents = allStudents.filter {
        (selectedCourse == "All" || it.course == selectedCourse) &&
        (selectedLevel == "All" || it.academicLevel == selectedLevel)
    }

    var correctionTarget by remember { mutableStateOf<CellCorrectionTarget?>(null) }
    var courseDropdownExpanded by remember { mutableStateOf(false) }
    var levelDropdownExpanded by remember { mutableStateOf(false) }

    val startFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
    val endFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val fridayCal = (selectedWeekMonday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 4) }
    val weekRangeLabel = "${startFormat.format(selectedWeekMonday.time)} – ${endFormat.format(fridayCal.time)}"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Weekly Attendance Register",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "5 Working Days (Mon – Fri) • Auto Biometric Marking",
                    fontSize = 11.sp,
                    color = EcuTextSecondary
                )
            }

            Surface(
                color = EcuNavy,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "5-Day Register",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuGoldLight
                    )
                }
            }
        }

        // Filter & Week Navigation Bar
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(10.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Week Nav Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = { viewModel.previousWeek() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("btn_prev_week")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Week", tint = EcuNavy)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = weekRangeLabel,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = EcuNavy
                        )
                    }

                    IconButton(
                        onClick = { viewModel.nextWeek() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("btn_next_week")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Week", tint = EcuNavy)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Course and Level Selectors
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Course Selector
                    ExposedDropdownMenuBox(
                        expanded = courseDropdownExpanded,
                        onExpandedChange = { courseDropdownExpanded = !courseDropdownExpanded },
                        modifier = Modifier.weight(1.5f)
                    ) {
                        OutlinedTextField(
                            value = selectedCourse,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Course / Programme", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = courseDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = courseDropdownExpanded,
                            onDismissRequest = { courseDropdownExpanded = false }
                        ) {
                            for (c in distinctCourses) {
                                DropdownMenuItem(
                                    text = { Text(c, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.setRegisterCourse(c)
                                        courseDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Level Selector
                    ExposedDropdownMenuBox(
                        expanded = levelDropdownExpanded,
                        onExpandedChange = { levelDropdownExpanded = !levelDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedLevel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Class Level", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = levelDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = levelDropdownExpanded,
                            onDismissRequest = { levelDropdownExpanded = false }
                        ) {
                            for (l in distinctLevels) {
                                DropdownMenuItem(
                                    text = { Text(l, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.setRegisterLevel(l)
                                        levelDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Legend Card
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(EcuSuccess),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text("Present (Green Tick)", fontSize = 11.sp, color = Color(0xFF065F46), fontWeight = FontWeight.SemiBold)

                Spacer(modifier = Modifier.width(14.dp))

                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEF4444)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text("Absent (Red Indicator)", fontSize = 11.sp, color = Color(0xFF991B1B), fontWeight = FontWeight.SemiBold)
            }

            Text(
                text = "${classStudents.size} Students Enrolled",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EcuNavy
            )
        }

        // The Weekly Attendance Register Table (Horizontal & Vertical Scrollable)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(10.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("weekly_register_table")
        ) {
            val horizontalScrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(horizontalScrollState)
            ) {
                // Table Header Row: No.| Student Name| Registration No.| Class| Monday| Tuesday| Wednesday| Thursday| Friday
                Row(
                    modifier = Modifier
                        .background(EcuNavy)
                        .padding(vertical = 10.dp, horizontal = 6.dp)
                ) {
                    TableCell(text = "No.", width = 45.dp, isHeader = true)
                    TableCell(text = "Student Name", width = 170.dp, isHeader = true)
                    TableCell(text = "Registration No.", width = 125.dp, isHeader = true)
                    TableCell(text = "Class", width = 85.dp, isHeader = true)
                    workingDays.forEach { (dayName, dateStr) ->
                        val shortDate = dateStr.takeLast(5)
                        TableCell(text = "$dayName\n$shortDate", width = 90.dp, isHeader = true)
                    }
                }

                HorizontalDivider(color = EcuBorder)

                // Table Rows
                if (classStudents.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No students registered for $selectedCourse ($selectedLevel).",
                            color = EcuTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        itemsIndexed(classStudents) { index, student ->
                            val rowBg = if (index % 2 == 0) Color.White else Color(0xFFF8FAFC)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(rowBg)
                                    .padding(vertical = 6.dp, horizontal = 6.dp)
                            ) {
                                // No.
                                TableCell(text = "${index + 1}", width = 45.dp)

                                // Student Name + Photo
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.width(170.dp)
                                ) {
                                    StudentPhotoView(
                                        photoPath = student.photoPath,
                                        fullName = student.fullName,
                                        size = 30.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = student.fullName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EcuTextPrimary,
                                        maxLines = 1
                                    )
                                }

                                // Registration No.
                                TableCell(text = student.registrationNumber, width = 125.dp, fontWeight = FontWeight.SemiBold)

                                // Class
                                TableCell(text = student.academicLevel, width = 85.dp)

                                // Monday to Friday Attendance Cells (Strictly 5 days!)
                                workingDays.forEach { (dayName, dateStr) ->
                                    val match = weekAttendanceRecords.find {
                                        it.studentRegistrationNumber == student.registrationNumber && it.dateString == dateStr
                                    }
                                    val isPresent = match?.status == "PRESENT"

                                    Box(
                                        modifier = Modifier
                                            .width(90.dp)
                                            .clickable {
                                                correctionTarget = CellCorrectionTarget(
                                                    student = student,
                                                    dayName = dayName,
                                                    dateString = dateStr,
                                                    currentRecord = match
                                                )
                                            }
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Surface(
                                            color = if (isPresent) Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (isPresent) Icons.Default.Check else Icons.Default.Close,
                                                    contentDescription = if (isPresent) "Present" else "Absent",
                                                    tint = if (isPresent) EcuSuccess else Color(0xFFEF4444),
                                                    modifier = Modifier.size(13.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(
                                                    text = if (isPresent) "Present" else "Absent",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isPresent) Color(0xFF065F46) else Color(0xFF991B1B)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }

    // Manual Correction Dialog
    if (correctionTarget != null) {
        val target = correctionTarget!!
        var selectedStatus by remember { mutableStateOf(if (target.currentRecord?.status == "PRESENT") "ABSENT" else "PRESENT") }
        var correctionReason by remember { mutableStateOf("") }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { correctionTarget = null },
            title = {
                Text(
                    text = "Manual Attendance Correction",
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Student: ${target.student.fullName} (${target.student.registrationNumber})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EcuTextPrimary
                    )
                    Text(
                        text = "Date: ${target.dayName}, ${target.dateString}",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                    if (target.currentRecord != null) {
                        Text(
                            text = "Current: ${target.currentRecord!!.status} (Marked by: ${target.currentRecord!!.markedByAdmin})",
                            fontSize = 11.sp,
                            color = EcuNavy
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Set New Attendance Status:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuTextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { selectedStatus = "PRESENT" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedStatus == "PRESENT") EcuSuccess else Color(0xFFF1F5F9)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "Mark PRESENT",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedStatus == "PRESENT") Color.White else EcuTextPrimary
                            )
                        }

                        Button(
                            onClick = { selectedStatus = "ABSENT" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedStatus == "ABSENT") Color(0xFFEF4444) else Color(0xFFF1F5F9)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "Mark ABSENT",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedStatus == "ABSENT") Color.White else EcuTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = correctionReason,
                        onValueChange = {
                            correctionReason = it
                            errorMessage = null
                        },
                        label = { Text("Correction Reason (Mandatory) *") },
                        placeholder = { Text("e.g. Approved medical leave, scanner retry, exam duty...") },
                        singleLine = false,
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFDC2626),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Text(
                        text = "Policy: All manual corrections are timestamped and logged with the administrator's ID.",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (correctionReason.trim().isEmpty()) {
                            errorMessage = "University policy requires specifying a valid reason for manual changes."
                            return@Button
                        }
                        viewModel.recordManualCorrection(
                            student = target.student,
                            dateStr = target.dateString,
                            dayOfWeek = target.dayName,
                            sessionName = "Regular Session",
                            newStatus = selectedStatus,
                            reason = correctionReason.trim()
                        ) { success, _ ->
                            if (success) {
                                correctionTarget = null
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy)
                ) {
                    Text("Save Correction")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { correctionTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false,
    fontWeight: FontWeight = FontWeight.Normal
) {
    Text(
        text = text,
        fontSize = if (isHeader) 11.sp else 11.sp,
        fontWeight = if (isHeader) FontWeight.Bold else fontWeight,
        color = if (isHeader) EcuGoldLight else EcuTextPrimary,
        textAlign = if (isHeader) TextAlign.Center else TextAlign.Start,
        maxLines = 2,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp)
    )
}
