package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emmanuel Christian University (ECU) Official Theme Palette
val EcuNavyDark = Color(0xFF071B34)
val EcuNavy = Color(0xFF0D2C54)
val EcuNavyLight = Color(0xFF134074)
val EcuBlue = Color(0xFF1D5C96)
val EcuBlueAccent = Color(0xFF2575FC)

val EcuGold = Color(0xFFD4AF37)
val EcuGoldLight = Color(0xFFF6D860)
val EcuGoldDark = Color(0xFFAA820A)
val EcuGoldContainer = Color(0xFFFFF7DB)

val EcuBackground = Color(0xFFF8FAFC)
val EcuSurface = Color(0xFFFFFFFF)
val EcuSurfaceVariant = Color(0xFFEEF2F6)
val EcuBorder = Color(0xFFCBD5E1)

val EcuTextPrimary = Color(0xFF0F172A)
val EcuTextSecondary = Color(0xFF475569)
val EcuTextMuted = Color(0xFF94A3B8)

val EcuSuccess = Color(0xFF10B981)
val EcuSuccessDark = Color(0xFF047857)
val EcuSuccessContainer = Color(0xFFD1FAE5)

val EcuError = Color(0xFFEF4444)
val EcuErrorDark = Color(0xFFB91C1C)
val EcuErrorContainer = Color(0xFFFEE2E2)

val EcuWarning = Color(0xFFF59E0B)
val EcuWarningContainer = Color(0xFFFEF3C7)
val EcuInfo = Color(0xFF0284C7)
