package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@Composable
fun SettingsScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val adminUser by viewModel.adminUsername.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()

    var academicYear by remember { mutableStateOf("2025/2026") }
    var currentSemester by remember { mutableStateOf("Semester 1") }
    var attendanceThreshold by remember { mutableFloatStateOf(75f) }
    var matchSensitivity by remember { mutableFloatStateOf(70f) }
    var autoLockMinutes by remember { mutableIntStateOf(15) }

    var showChangePasswordDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = EcuNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "System Settings & Configuration",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "ECU DATA ATTENDANCE Administrator Preferences",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
            }
        }

        // University Profile & Branding Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(EcuNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ecu_logo),
                        contentDescription = "ECU Logo",
                        modifier = Modifier.size(54.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "EMMANUEL CHRISTIAN UNIVERSITY",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EcuNavy
                    )
                    Text(
                        text = "ECU DATA ATTENDANCE v1.0",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuGoldDark
                    )
                    Text(
                        text = "Juba, South Sudan • Offline Biometric Campus Edition",
                        fontSize = 11.sp,
                        color = EcuTextSecondary
                    )
                }
            }
        }

        // Academic Calendar & Session Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.School, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Academic & Attendance Parameters", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EcuNavy)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text("Academic Year") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = currentSemester,
                        onValueChange = { currentSemester = it },
                        label = { Text("Semester") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Minimum Exam Attendance Threshold: ${attendanceThreshold.toInt()}%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EcuTextPrimary
                )
                Slider(
                    value = attendanceThreshold,
                    onValueChange = { attendanceThreshold = it },
                    valueRange = 50f..90f,
                    steps = 7,
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = EcuNavy,
                        activeTrackColor = EcuGoldDark
                    )
                )
            }
        }

        // Biometric Scanner Configuration
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Biometric Scanner Configuration", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EcuNavy)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Detected Hardware: ${hardwareStatus.deviceName}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = EcuTextPrimary)
                Text("Connection Interface: ${hardwareStatus.deviceType}", fontSize = 12.sp, color = EcuTextSecondary)

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Template Match Confidence Threshold: ${matchSensitivity.toInt()}%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EcuTextPrimary
                )
                Slider(
                    value = matchSensitivity,
                    onValueChange = { matchSensitivity = it },
                    valueRange = 60f..95f,
                    steps = 6,
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = EcuNavy,
                        activeTrackColor = EcuNavy
                    )
                )
            }
        }

        // Administrator Security & Auto-Lock Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = EcuNavy, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Administrator Security & Authentication", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EcuNavy)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Current Administrator: $adminUser", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = EcuTextPrimary)
                Text("Inactivity Auto-Lock: $autoLockMinutes minutes", fontSize = 12.sp, color = EcuTextSecondary)

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showChangePasswordDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_change_admin_password")
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = EcuGoldLight, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Change Admin Password")
                }
            }
        }
    }

    // Change Password Dialog
    if (showChangePasswordDialog) {
        var currentPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Change Administrator Password", fontWeight = FontWeight.Bold, color = EcuNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (errorMsg != null) {
                        Text(errorMsg!!, color = Color(0xFFDC2626), fontSize = 12.sp)
                    }

                    OutlinedTextField(
                        value = currentPass,
                        onValueChange = { currentPass = it },
                        label = { Text("Current Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password (min 4 characters)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("Confirm New Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass != confirmPass) {
                            errorMsg = "New passwords do not match"
                            return@Button
                        }
                        viewModel.changePassword(currentPass, newPass) { success, msg ->
                            if (success) {
                                showChangePasswordDialog = false
                            } else {
                                errorMsg = msg
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy)
                ) {
                    Text("Update Password")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showChangePasswordDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
