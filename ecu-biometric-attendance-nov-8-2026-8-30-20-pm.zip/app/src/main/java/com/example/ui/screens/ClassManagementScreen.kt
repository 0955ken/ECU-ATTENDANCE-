package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AcademicProgramEntity
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@Composable
fun ClassManagementScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val programs by viewModel.allPrograms.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var programToEdit by remember { mutableStateOf<AcademicProgramEntity?>(null) }
    var programToDelete by remember { mutableStateOf<AcademicProgramEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EcuNavy,
                contentColor = EcuGold
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Program")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(EcuBackground)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Class,
                    contentDescription = null,
                    tint = EcuNavy,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Class & Academic Organization",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Text(
                        text = "Faculties, Departments, Programmes, and Academic Levels",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(programs, key = { it.id }) { program ->
                    val enrolledInProgram = allStudents.filter { it.course == program.programmeName }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(
                                    color = EcuNavy,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = program.programmeCode,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = { programToEdit = program },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = EcuNavy, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = { programToDelete = program },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = program.programmeName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuTextPrimary
                            )

                            Text(
                                text = "${program.faculty} • ${program.department}",
                                fontSize = 12.sp,
                                color = EcuTextSecondary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "Levels: ${program.levels}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = EcuNavy
                                )
                                Text(
                                    text = "${enrolledInProgram.size} Students Enrolled",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EcuGoldDark
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Program Dialog
    if (showAddDialog || programToEdit != null) {
        val editing = programToEdit != null
        var faculty by remember { mutableStateOf(programToEdit?.faculty ?: "Faculty of Business Administration") }
        var department by remember { mutableStateOf(programToEdit?.department ?: "Department of Management") }
        var programmeName by remember { mutableStateOf(programToEdit?.programmeName ?: "") }
        var programmeCode by remember { mutableStateOf(programToEdit?.programmeCode ?: "") }
        var levels by remember { mutableStateOf(programToEdit?.levels ?: "Year 1,Year 2,Year 3,Year 4") }
        var academicYear by remember { mutableStateOf(programToEdit?.academicYear ?: "2025/2026") }

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                programToEdit = null
            },
            title = {
                Text(
                    text = if (editing) "Edit Academic Programme" else "Add Academic Programme",
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = programmeName,
                        onValueChange = { programmeName = it },
                        label = { Text("Programme Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = programmeCode,
                        onValueChange = { programmeCode = it },
                        label = { Text("Code (e.g. BBA, BSc IT) *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = faculty,
                        onValueChange = { faculty = it },
                        label = { Text("Faculty *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = department,
                        onValueChange = { department = it },
                        label = { Text("Department *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = levels,
                        onValueChange = { levels = it },
                        label = { Text("Levels (comma-separated)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text("Academic Year") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (programmeName.isNotBlank() && programmeCode.isNotBlank()) {
                            val entity = (programToEdit ?: AcademicProgramEntity(
                                faculty = faculty,
                                department = department,
                                programmeName = programmeName,
                                programmeCode = programmeCode,
                                levels = levels,
                                academicYear = academicYear
                            )).copy(
                                faculty = faculty.trim(),
                                department = department.trim(),
                                programmeName = programmeName.trim(),
                                programmeCode = programmeCode.trim(),
                                levels = levels.trim(),
                                academicYear = academicYear.trim()
                            )

                            if (editing) {
                                viewModel.updateAcademicProgram(entity)
                            } else {
                                viewModel.addAcademicProgram(entity)
                            }
                            showAddDialog = false
                            programToEdit = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuNavy)
                ) {
                    Text("Save Programme")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    showAddDialog = false
                    programToEdit = null
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirmation
    if (programToDelete != null) {
        AlertDialog(
            onDismissRequest = { programToDelete = null },
            title = { Text("Remove Academic Programme", fontWeight = FontWeight.Bold, color = EcuNavy) },
            text = { Text("Are you sure you want to remove ${programToDelete!!.programmeName}?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAcademicProgram(programToDelete!!.id)
                        programToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { programToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
