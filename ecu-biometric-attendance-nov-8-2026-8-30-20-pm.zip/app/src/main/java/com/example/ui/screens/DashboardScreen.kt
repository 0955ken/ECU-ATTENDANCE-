package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AttendanceRecordEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuNavyLight
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuSuccessContainer
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@Composable
fun DashboardScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val todayRecords by viewModel.todayAttendance.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()
    val todayDate by viewModel.todayDateString.collectAsState()

    val studentMap = allStudents.associateBy { it.registrationNumber }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner & Quick Action Launch
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EcuNavy),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_hero_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "EMMANUEL CHRISTIAN UNIVERSITY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuGoldLight,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Attendance Operations Center",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "Today: $todayDate  •  Academic Year 2025/2026",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        Surface(
                            color = EcuNavyDark,
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (hardwareStatus.isReady) EcuSuccess else EcuGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (hardwareStatus.isReady) "Scanner Active" else "Scanner Standby",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Primary Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onNavigate(AppScreen.BIOMETRIC_ATTENDANCE) },
                            colors = ButtonDefaults.buttonColors(containerColor = EcuGold),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_launch_biometric_attendance")
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = EcuNavyDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Biometric Verify",
                                color = EcuNavyDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { onNavigate(AppScreen.WEEKLY_ATTENDANCE_REGISTER) },
                            colors = ButtonDefaults.buttonColors(containerColor = EcuNavyLight),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_launch_weekly_register")
                        ) {
                            Icon(
                                imageVector = Icons.Default.HowToReg,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Weekly Register",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Primary Metric Statistics Grid (4 Key Cards)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        title = "Total Students",
                        value = "${stats.totalStudents}",
                        subtitle = "Enrolled",
                        icon = Icons.Default.People,
                        cardColor = Color.White,
                        iconTint = EcuNavy,
                        modifier = Modifier.weight(1f),
                        testTag = "stat_total_students"
                    )

                    MetricStatCard(
                        title = "Present Today",
                        value = "${stats.presentToday}",
                        subtitle = "${stats.attendanceRatePercent}% attendance",
                        icon = Icons.Default.CheckCircle,
                        cardColor = Color.White,
                        iconTint = EcuSuccess,
                        modifier = Modifier.weight(1f),
                        testTag = "stat_present_today"
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        title = "Absent Today",
                        value = "${stats.absentToday}",
                        subtitle = "Unmarked",
                        icon = Icons.Default.Close,
                        cardColor = Color.White,
                        iconTint = Color(0xFFEF4444),
                        modifier = Modifier.weight(1f),
                        testTag = "stat_absent_today"
                    )

                    MetricStatCard(
                        title = "Total Records",
                        value = "${stats.totalAttendanceRecords}",
                        subtitle = "Database Entries",
                        icon = Icons.Default.Assessment,
                        cardColor = Color.White,
                        iconTint = EcuGoldDark,
                        modifier = Modifier.weight(1f),
                        testTag = "stat_total_records"
                    )
                }
            }
        }

        // Attendance Percentage Gauge Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = EcuNavy,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Today's Attendance Rate",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuTextPrimary
                            )
                        }

                        Text(
                            text = "${stats.attendanceRatePercent}%",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (stats.attendanceRatePercent >= 75) EcuSuccess else EcuGoldDark
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (stats.attendanceRatePercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = if (stats.attendanceRatePercent >= 75) EcuSuccess else EcuGoldDark,
                        trackColor = Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${stats.presentToday} students present",
                            fontSize = 11.sp,
                            color = EcuSuccess,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${stats.absentToday} students pending / absent",
                            fontSize = 11.sp,
                            color = Color(0xFFEF4444),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Faculty Distribution Breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = EcuNavy,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Students Registered by Faculty",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = EcuTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (stats.facultyBreakdown.isEmpty()) {
                        Text(
                            text = "No faculty data loaded yet.",
                            fontSize = 12.sp,
                            color = EcuTextSecondary
                        )
                    } else {
                        stats.facultyBreakdown.forEach { (facultyName, count) ->
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = facultyName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = EcuTextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "$count students",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EcuNavy
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                val facultyFraction = if (stats.totalStudents > 0) count.toFloat() / stats.totalStudents else 0f
                                LinearProgressIndicator(
                                    progress = { facultyFraction },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = EcuNavy,
                                    trackColor = Color(0xFFF1F5F9)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Today Attendance Feed Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Live Verification Activity (Today)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuTextPrimary
                )
                Text(
                    text = "${todayRecords.size} Scans",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EcuGoldDark
                )
            }
        }

        // Live Today Attendance Record Items
        if (todayRecords.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null,
                            tint = Color(0xFFCBD5E1),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No biometric attendance marked yet today",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = EcuTextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { onNavigate(AppScreen.BIOMETRIC_ATTENDANCE) },
                            colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Open Biometric Scanner", fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            items(todayRecords) { record ->
                val student = studentMap[record.studentRegistrationNumber]
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        StudentPhotoView(
                            photoPath = student?.photoPath,
                            fullName = record.studentFullName,
                            size = 46.dp
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = record.studentFullName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuTextPrimary
                            )
                            Text(
                                text = "${record.studentRegistrationNumber}  •  ${record.academicLevel}",
                                fontSize = 12.sp,
                                color = EcuTextSecondary
                            )
                            Text(
                                text = "${record.course} (${record.sessionName})",
                                fontSize = 11.sp,
                                color = EcuNavy,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Surface(
                                color = if (record.status == "PRESENT") Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (record.status == "PRESENT") Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = if (record.status == "PRESENT") EcuSuccess else Color(0xFFEF4444),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = record.status,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (record.status == "PRESENT") Color(0xFF065F46) else Color(0xFF991B1B)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = record.verifiedTimeFormatted,
                                fontSize = 11.sp,
                                color = EcuTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    cardColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.testTag(testTag)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EcuTextSecondary
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = EcuTextPrimary
            )

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = EcuTextSecondary
            )
        }
    }
}
