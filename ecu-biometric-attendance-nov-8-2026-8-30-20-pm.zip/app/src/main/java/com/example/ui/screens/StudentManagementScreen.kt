package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudentEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel

@Composable
fun StudentManagementScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val students by viewModel.filteredStudents.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var studentToEdit by remember { mutableStateOf<StudentEntity?>(null) }
    var studentToDelete by remember { mutableStateOf<StudentEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EcuNavy,
                contentColor = EcuGold,
                modifier = Modifier.testTag("fab_add_student")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Student")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(EcuBackground)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Search Bar & Stats Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Student Directory",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuNavy
                    )
                    Text(
                        text = "${students.size} of ${allStudents.size} students shown",
                        fontSize = 12.sp,
                        color = EcuTextSecondary
                    )
                }

                Button(
                    onClick = { onNavigate(AppScreen.UPLOAD_STUDENT_LISTS) },
                    colors = ButtonDefaults.buttonColors(containerColor = EcuGold),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_batch_upload")
                ) {
                    Text(
                        text = "Batch Upload",
                        color = EcuNavyDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search by student name, registration no, or ID...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EcuNavy) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search", tint = EcuNavy)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EcuNavy,
                    unfocusedBorderColor = EcuBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("student_search_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Student List
            if (students.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color(0xFFCBD5E1),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isBlank()) "No students found." else "No matches for '$searchQuery'",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = EcuTextSecondary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EcuNavy)
                        ) {
                            Text("Register New Student")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(students, key = { it.id }) { student ->
                        StudentCard(
                            student = student,
                            onPhotoSelected = { uri -> viewModel.saveStudentPhoto(student.id, uri) },
                            onEdit = { studentToEdit = student },
                            onDelete = { studentToDelete = student },
                            onRegisterBiometric = {
                                onNavigate(AppScreen.FINGERPRINT_REGISTRATION)
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Student Dialog
    if (showAddDialog || studentToEdit != null) {
        val editing = studentToEdit != null
        StudentFormDialog(
            initialStudent = studentToEdit,
            onDismiss = {
                showAddDialog = false
                studentToEdit = null
            },
            onSave = { student ->
                if (editing) {
                    viewModel.updateStudent(student) { success, _ ->
                        if (success) {
                            studentToEdit = null
                        }
                    }
                } else {
                    viewModel.addStudent(student) { success, _ ->
                        if (success) {
                            showAddDialog = false
                        }
                    }
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (studentToDelete != null) {
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            title = { Text("Delete Student Record", fontWeight = FontWeight.Bold, color = EcuNavy) },
            text = {
                Text(
                    "Are you sure you want to delete ${studentToDelete!!.fullName} (${studentToDelete!!.registrationNumber})? This will permanently remove their biometric records."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudent(studentToDelete!!)
                        studentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { studentToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun StudentCard(
    student: StudentEntity,
    onPhotoSelected: (Uri) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRegisterBiometric: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("student_card_${student.registrationNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Student Photo with live upload button
                StudentPhotoView(
                    photoPath = student.photoPath,
                    fullName = student.fullName,
                    size = 54.dp,
                    canEdit = true,
                    onPhotoSelected = onPhotoSelected
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.fullName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = EcuTextPrimary
                    )
                    Text(
                        text = "Reg No: ${student.registrationNumber}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EcuNavy
                    )
                    Text(
                        text = "${student.course} • ${student.academicLevel}",
                        fontSize = 11.sp,
                        color = EcuTextSecondary
                    )
                    Text(
                        text = "${student.faculty} (${student.academicYear})",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                }

                // Edit & Delete Icons
                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("edit_student_${student.registrationNumber}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Student", tint = EcuNavy, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_student_${student.registrationNumber}")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Student", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Biometric Registration Status & Enrollment Action
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = null,
                        tint = if (student.isBiometricRegistered) EcuSuccess else Color(0xFFF59E0B),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (student.isBiometricRegistered) "Biometrics Enrolled (${student.biometricFingerType})" else "Biometrics Pending",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (student.isBiometricRegistered) Color(0xFF065F46) else Color(0xFFB45309)
                    )
                }

                Button(
                    onClick = onRegisterBiometric,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (student.isBiometricRegistered) EcuNavy else EcuGold
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = ButtonDefaults.ContentPadding,
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("btn_enroll_finger_${student.registrationNumber}")
                ) {
                    Text(
                        text = if (student.isBiometricRegistered) "Update Print" else "Enroll Print",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (student.isBiometricRegistered) Color.White else EcuNavyDark
                    )
                }
            }
        }
    }
}

@Composable
fun StudentFormDialog(
    initialStudent: StudentEntity?,
    onDismiss: () -> Unit,
    onSave: (StudentEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(initialStudent?.fullName ?: "") }
    var regNo by remember { mutableStateOf(initialStudent?.registrationNumber ?: "") }
    var studentIdNumber by remember { mutableStateOf(initialStudent?.studentIdNumber ?: "") }
    var faculty by remember { mutableStateOf(initialStudent?.faculty ?: "Faculty of Business Administration") }
    var department by remember { mutableStateOf(initialStudent?.department ?: "Department of Management & Accounting") }
    var course by remember { mutableStateOf(initialStudent?.course ?: "Bachelor of Business Administration") }
    var academicYear by remember { mutableStateOf(initialStudent?.academicYear ?: "2025/2026") }
    var academicLevel by remember { mutableStateOf(initialStudent?.academicLevel ?: "Year 2") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialStudent != null) "Edit Student Information" else "Register New Student",
                fontWeight = FontWeight.Bold,
                color = EcuNavy
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = Color(0xFFDC2626),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_fullname")
                )

                OutlinedTextField(
                    value = regNo,
                    onValueChange = {
                        regNo = it
                        if (studentIdNumber.isBlank()) {
                            studentIdNumber = "ECU-${it.replace("/", "-")}"
                        }
                    },
                    label = { Text("Registration Number (e.g. 24/BBA/006) *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_student_regno")
                )

                OutlinedTextField(
                    value = studentIdNumber,
                    onValueChange = { studentIdNumber = it },
                    label = { Text("Student Identification Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = faculty,
                    onValueChange = { faculty = it },
                    label = { Text("Faculty *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = department,
                    onValueChange = { department = it },
                    label = { Text("Department *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = course,
                    onValueChange = { course = it },
                    label = { Text("Course or Programme *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text("Academic Year") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = academicLevel,
                        onValueChange = { academicLevel = it },
                        label = { Text("Class / Level") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fullName.isBlank() || regNo.isBlank() || course.isBlank()) {
                        errorMessage = "Please fill in all mandatory fields (Name, Reg No, Course)."
                        return@Button
                    }
                    val updated = (initialStudent ?: StudentEntity(
                        fullName = fullName.trim(),
                        registrationNumber = regNo.trim(),
                        studentIdNumber = studentIdNumber.ifBlank { "ECU-${regNo.replace("/", "-")}" },
                        faculty = faculty.trim(),
                        department = department.trim(),
                        course = course.trim(),
                        academicYear = academicYear.trim(),
                        academicLevel = academicLevel.trim()
                    )).copy(
                        fullName = fullName.trim(),
                        registrationNumber = regNo.trim(),
                        studentIdNumber = studentIdNumber.ifBlank { "ECU-${regNo.replace("/", "-")}" },
                        faculty = faculty.trim(),
                        department = department.trim(),
                        course = course.trim(),
                        academicYear = academicYear.trim(),
                        academicLevel = academicLevel.trim()
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                modifier = Modifier.testTag("btn_save_student_modal")
            ) {
                Text("Save Student")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
