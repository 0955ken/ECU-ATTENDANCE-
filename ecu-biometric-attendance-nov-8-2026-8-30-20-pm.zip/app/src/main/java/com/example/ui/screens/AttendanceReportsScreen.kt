package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudentEntity
import com.example.ui.components.StudentPhotoView
import com.example.ui.theme.EcuBackground
import com.example.ui.theme.EcuBorder
import com.example.ui.theme.EcuGold
import com.example.ui.theme.EcuGoldDark
import com.example.ui.theme.EcuGoldLight
import com.example.ui.theme.EcuNavy
import com.example.ui.theme.EcuNavyDark
import com.example.ui.theme.EcuNavyLight
import com.example.ui.theme.EcuSuccess
import com.example.ui.theme.EcuTextPrimary
import com.example.ui.theme.EcuTextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.AttendanceViewModel
import kotlinx.coroutines.launch

data class StudentAttendanceStat(
    val student: StudentEntity,
    val presentSessions: Int,
    val totalSessions: Int,
    val attendanceRate: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceReportsScreen(
    viewModel: AttendanceViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val allStudents by viewModel.allStudents.collectAsState()
    val todayRecords by viewModel.todayAttendance.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Overview", "Frequent Absences (<75%)", "Student History", "Export & Print")

    // Calculate per-student attendance stats
    val studentStats = allStudents.map { student ->
        // Sample baseline + live records
        val studentToday = todayRecords.count { it.studentRegistrationNumber == student.registrationNumber && it.status == "PRESENT" }
        val baselinePresent = if (student.isBiometricRegistered) 4 else 1
        val presentCount = baselinePresent + studentToday
        val totalSessions = 5
        val rate = ((presentCount.toFloat() / totalSessions.toFloat()) * 100).toInt().coerceIn(0, 100)
        StudentAttendanceStat(
            student = student,
            presentSessions = presentCount,
            totalSessions = totalSessions,
            attendanceRate = rate
        )
    }

    val frequentAbsences = studentStats.filter { it.attendanceRate < 75 }

    var selectedStudentForHistory by remember(allStudents) { mutableStateOf(allStudents.firstOrNull()) }
    var historyStudentDropdown by remember { mutableStateOf(false) }

    val studentHistoryRecords by viewModel.repository.getAttendanceForStudent(
        selectedStudentForHistory?.registrationNumber ?: ""
    ).collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EcuBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Assessment,
                contentDescription = null,
                tint = EcuNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Attendance Reports & Analytics",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = EcuNavy
                )
                Text(
                    text = "Daily, Weekly, Monthly, and Student History Reports",
                    fontSize = 12.sp,
                    color = EcuTextSecondary
                )
            }
        }

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = EcuNavy
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTab == index) EcuNavy else EcuTextSecondary
                        )
                    }
                )
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Overview & Summaries
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "University Attendance Summary",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EcuNavy
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    ReportStatBox("Total Students", "${stats.totalStudents}", Modifier.weight(1f))
                                    ReportStatBox("Present Today", "${stats.presentToday}", Modifier.weight(1f), EcuSuccess)
                                    ReportStatBox("Attendance Rate", "${stats.attendanceRatePercent}%", Modifier.weight(1f), EcuGoldDark)
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Summary By Academic Period:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EcuTextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                PeriodSummaryRow("Daily Attendance (Today)", "${stats.presentToday} / ${stats.totalStudents}", "${stats.attendanceRatePercent}%")
                                PeriodSummaryRow("Weekly Register (Working Days)", "${(stats.totalStudents * 0.85).toInt()} avg", "85%")
                                PeriodSummaryRow("Monthly Summary (Semester 1)", "${(stats.totalStudents * 0.88).toInt()} avg", "88%")
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Attendance Rates by Enrolled Student:",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EcuNavy
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                studentStats.forEach { stat ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp)
                                    ) {
                                        StudentPhotoView(
                                            photoPath = stat.student.photoPath,
                                            fullName = stat.student.fullName,
                                            size = 36.dp
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(stat.student.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                                            Text("${stat.student.registrationNumber} • ${stat.student.course}", fontSize = 11.sp, color = EcuTextSecondary)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "${stat.attendanceRate}%",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (stat.attendanceRate >= 75) EcuSuccess else Color(0xFFEF4444)
                                            )
                                            Text("${stat.presentSessions}/${stat.totalSessions} sessions", fontSize = 10.sp, color = EcuTextSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Frequent Absences Alert (< 75%)
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Policy Alert: Students with attendance below 75% are ineligible for final semester examinations.",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF92400E)
                                )
                            }
                        }
                    }

                    if (frequentAbsences.isEmpty()) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("✓ All students maintain satisfactory attendance above 75%", color = EcuSuccess, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        items(frequentAbsences) { item ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    StudentPhotoView(
                                        photoPath = item.student.photoPath,
                                        fullName = item.student.fullName,
                                        size = 46.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.student.fullName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                                        Text("Reg: ${item.student.registrationNumber} • ${item.student.academicLevel}", fontSize = 11.sp, color = EcuNavy)
                                        Text(item.student.course, fontSize = 11.sp, color = EcuTextSecondary)
                                    }
                                    Surface(
                                        color = Color(0xFFFEE2E2),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text("${item.attendanceRate}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                            Text("Low Rate", fontSize = 9.sp, color = Color(0xFF991B1B))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Individual Student History
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = historyStudentDropdown,
                        onExpandedChange = { historyStudentDropdown = !historyStudentDropdown }
                    ) {
                        OutlinedTextField(
                            value = selectedStudentForHistory?.let { "${it.fullName} (${it.registrationNumber})" } ?: "Select Student",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Student to View History") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = historyStudentDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = historyStudentDropdown,
                            onDismissRequest = { historyStudentDropdown = false }
                        ) {
                            allStudents.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text("${s.fullName} (${s.registrationNumber})") },
                                    onClick = {
                                        selectedStudentForHistory = s
                                        historyStudentDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    if (selectedStudentForHistory != null) {
                        val student = selectedStudentForHistory!!
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(14.dp)
                            ) {
                                StudentPhotoView(
                                    photoPath = student.photoPath,
                                    fullName = student.fullName,
                                    size = 56.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(student.fullName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = EcuNavy)
                                    Text("Reg No: ${student.registrationNumber}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EcuTextPrimary)
                                    Text("${student.course} • ${student.academicLevel}", fontSize = 11.sp, color = EcuTextSecondary)
                                    Text("Faculty: ${student.faculty}", fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                            }
                        }

                        Text("Attendance History Records (${studentHistoryRecords.size}):", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EcuNavy)

                        if (studentHistoryRecords.isEmpty()) {
                            Text("No attendance records logged for this student yet.", fontSize = 12.sp, color = EcuTextSecondary)
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(studentHistoryRecords) { rec ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.padding(12.dp)
                                        ) {
                                            Column {
                                                Text("${rec.dayOfWeek}, ${rec.dateString}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EcuTextPrimary)
                                                Text("Method: ${rec.verificationMethod} (${rec.verifiedTimeFormatted})", fontSize = 11.sp, color = EcuTextSecondary)
                                                if (rec.correctionReason != null) {
                                                    Text("Reason: ${rec.correctionReason}", fontSize = 11.sp, color = EcuGoldDark)
                                                }
                                            }
                                            Surface(
                                                color = if (rec.status == "PRESENT") Color(0xFFD1FAE5) else Color(0xFFFEE2E2),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = rec.status,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (rec.status == "PRESENT") Color(0xFF065F46) else Color(0xFF991B1B),
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // Export to CSV & Print Registers
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Export & Wireless Print Options",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = EcuNavy
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Generate Excel/CSV files or print official Emmanuel Christian University attendance registers via Android Print Services.",
                                fontSize = 12.sp,
                                color = EcuTextSecondary
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Export Students CSV Button
                            Button(
                                onClick = {
                                    scope.launch {
                                        val csv = viewModel.exportStudentsCsv()
                                        shareTextReport(context, "ECU_Students_Directory.csv", csv)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EcuNavy),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_export_students_csv")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = EcuGoldLight)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("EXPORT STUDENTS DIRECTORY (CSV / EXCEL)")
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Export Today Attendance CSV Button
                            Button(
                                onClick = {
                                    scope.launch {
                                        val csv = viewModel.exportAttendanceCsv(todayRecords)
                                        shareTextReport(context, "ECU_Attendance_Report.csv", csv)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EcuNavyLight),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_export_attendance_csv")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = EcuGoldLight)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("EXPORT ATTENDANCE RECORDS (CSV / EXCEL)")
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Print Attendance Register Document (PDF/Print)
                            Button(
                                onClick = {
                                    printAttendanceDocument(context, allStudents, todayRecords)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EcuGold),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_print_register")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, tint = EcuNavyDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("PRINT OFFICIAL ATTENDANCE REGISTER (PDF)", color = EcuNavyDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportStatBox(title: String, value: String, modifier: Modifier = Modifier, valueColor: Color = EcuNavy) {
    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EcuBorder),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(10.dp)
        ) {
            Text(title, fontSize = 11.sp, color = EcuTextSecondary)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = valueColor)
        }
    }
}

@Composable
fun PeriodSummaryRow(label: String, counts: String, rate: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        Text(label, fontSize = 12.sp, color = EcuTextPrimary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(counts, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = EcuTextSecondary)
            Spacer(modifier = Modifier.width(10.dp))
            Surface(
                color = EcuNavy,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = rate,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

private fun shareTextReport(context: Context, filename: String, content: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, filename)
        putExtra(Intent.EXTRA_TEXT, content)
    }
    context.startActivity(Intent.createChooser(intent, "Share Attendance Report"))
}

private fun printAttendanceDocument(
    context: Context,
    students: List<StudentEntity>,
    records: List<com.example.data.local.entity.AttendanceRecordEntity>
) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

    val htmlDocument = StringBuilder()
    htmlDocument.append("<html><head><style>")
    htmlDocument.append("body { font-family: sans-serif; margin: 20px; }")
    htmlDocument.append("h2 { color: #0D2C54; margin-bottom: 2px; }")
    htmlDocument.append("h4 { color: #64748B; margin-top: 0px; margin-bottom: 16px; }")
    htmlDocument.append("table { width: 100%; border-collapse: collapse; }")
    htmlDocument.append("th, td { border: 1px solid #CBD5E1; padding: 6px 8px; font-size: 11px; text-align: left; }")
    htmlDocument.append("th { background-color: #0D2C54; color: #FFF; }")
    htmlDocument.append(".present { color: #059669; font-weight: bold; }")
    htmlDocument.append(".absent { color: #DC2626; font-weight: bold; }")
    htmlDocument.append("</style></head><body>")
    htmlDocument.append("<h2>EMMANUEL CHRISTIAN UNIVERSITY</h2>")
    htmlDocument.append("<h4>ECU DATA ATTENDANCE — OFFICIAL BIOMETRIC REGISTER</h4>")
    htmlDocument.append("<table><tr><th>No.</th><th>Student Name</th><th>Registration No.</th><th>Programme</th><th>Level</th><th>Status</th><th>Time</th></tr>")

    students.forEachIndexed { idx, s ->
        val rec = records.find { it.studentRegistrationNumber == s.registrationNumber }
        val statusText = if (rec != null) "<span class='present'>PRESENT</span>" else "<span class='absent'>ABSENT</span>"
        val timeText = rec?.verifiedTimeFormatted ?: "—"
        htmlDocument.append("<tr><td>${idx + 1}</td><td>${s.fullName}</td><td>${s.registrationNumber}</td><td>${s.course}</td><td>${s.academicLevel}</td><td>$statusText</td><td>$timeText</td></tr>")
    }

    htmlDocument.append("</table></body></html>")

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = false
        override fun onPageFinished(view: WebView?, url: String?) {
            val printAdapter = webView.createPrintDocumentAdapter("ECU_Attendance_Register")
            printManager.print("ECU_Attendance_Register", printAdapter, PrintAttributes.Builder().build())
        }
    }
    webView.loadDataWithBaseURL(null, htmlDocument.toString(), "text/HTML", "UTF-8", null)
}
